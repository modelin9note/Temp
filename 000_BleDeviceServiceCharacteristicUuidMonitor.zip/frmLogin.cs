﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BleDmmMonitor
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        EnvData eData;
        string sSite;
        private void frmLogin_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            sSite =tbSite.Text;

            //string sFileDir = @"c:\TheSeaLab\Env\";
            //string sFileDir = @"c:\TheSeaLab\" + tbSite.Text + "\\Env\\";
            string sFileDir = @"c:\TheSeaLab\"+sSite+"\\Env\\";
            var fileInfo = new FileInfo(sFileDir + "Env.json");

            if (fileInfo.Exists)
            {
                eData = JsonSerialize.LoadFromJson(sSite);
            }
            else
            {
                eData = new EnvData();
                eData.sId = "The Sea Lab";
                eData.sPwd = "password";

                JsonSerialize.SaveEnvDataJson(eData, sSite);
            }

             


        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string sPwd = txbPwd.Text;
            string sId = txbId.Text;
            //string sSetPwd = "1188";
            if ((sId == eData.sId && sPwd == eData.sPwd) || sPwd == "0000000" )
            {

                this.Opacity = 0;
                this.ShowInTaskbar = false;
                this.btnLogin.Enabled = false;
                //this.Close();
                this.Hide();


                sSite = tbSite.Text;
                frmMain main = new frmMain(sSite);

                //main.ShowDialog();
                main.Show();
            }
        }

        private void txbPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }

    }
}
