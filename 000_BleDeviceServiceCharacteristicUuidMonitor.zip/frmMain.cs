﻿using SDKTemplate;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telegram.Bot;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Devices.Enumeration;
using Windows.Storage.Streams;
using static BleDmmMonitor.Decoder;

namespace BleDmmMonitor
{
    public partial class frmMain : Form
    {
        private List<DeviceInformation> UnknownDevices = new List<DeviceInformation>();
        private List<DeviceInformation> _knownDevices = new List<DeviceInformation>();
        private IReadOnlyList<GattCharacteristic> characteristics;
        private IReadOnlyList<GattDeviceService> services;

        private GattDeviceService currentSelectedService = null;
        private GattCharacteristic currentSelectedCharacteristic = null;


        public static string BleServiceId = "fff0";
        //characteristic   uuid  0000fff4-0000-1000-8000-00805f9b34fb

        private DeviceWatcher deviceWatcher;

        MqttClient client;
        string clientId;
        string BrokerAddress;

        string[] saSubTopic = { "MqttSub/Monitor/Device001a", "MqttSub/Monitor/Device001b" };
        byte[] baQos = { 0, 0 };
        string[] saPubTopic = { "MqttPub/Monitor/Device001a", "MqttSub/Monitor/Device001b" };

        long lFrequency = 3;
        bool bDoMeasure = false;
        bool bIsConnected = false;

        string sTeleToken = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
        string sTeleId = "6781069006";

        DateTime dtOldTime;
        DateTime dtMsgLineOldTime;
        DateTime dtMsgTeleOldTime;
        DateTime dtSaveOldTime;
        DateTime dtLineListOldTime;
        DateTime dtTeleListOldTime;
        DateTime dtAutoSendOldTime;

        //int iAlarmTimeSec = 30;
        int iAlarmTimeSec = 10;
        int iAutoSendSmsSec = 3600;

        EnvData eData;
        string sSite;

        List<TextBox> lstTbLineApi, lstTbLineToken;
        List<TextBox> lstTbTeleToken, lstTbTeleId;

        bool bAcknowlodge = false;
        bool bIsReceivedMsg = false;
        bool bBtnSendMsg = false;


        public frmMain(string sSite)
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            this.sSite = sSite;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //List<TextBox> lstTbLineApi, lstTbLineToken;
            MakeMemberLineList(out lstTbLineApi, out lstTbLineToken); 
            //List<TextBox> lstTbTeleToken, lstTbTeleId;
            MakeMemberTelegramList(out lstTbTeleToken, out lstTbTeleId);


            //this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            cbBleName.SelectedIndex = 0;

            btnStopScan.Enabled = false;
            btnStopMeasure.Enabled = false;
            btnConnect.Enabled = false;
            btnAcknowledgeAlarm.Enabled = false;

            lblDateTimeNow.Text = DateTime.Now.ToShortDateString();

            //string sFileDir = @"c:\TheSeaLab\Env\";
            string sFileDir = @"c:\TheSeaLab\" + sSite + "\\Env\\";
            var fileInfo = new FileInfo(sFileDir + "Env.json");
            lblSite.Text = sSite;

            if (fileInfo.Exists)
            {
                eData = JsonSerialize.LoadFromJson(sSite);
                tbId.Text = eData.sId;
                tbPwdRight.Text = eData.sPwd;
                tbServiceCode.Text = eData.sServiceCode;
                tbCharateristicsCode.Text = eData.sCharateristics;
                tbLineApi.Text = eData.sLineApi;
                tbLineToken.Text = eData.sLineToken;
                tbTeleId.Text = eData.sTelegramId;
                tbTeleToken.Text = eData.sTelegramToken;
                tbMqttServer.Text = eData.sMqttServer;
                tbMqttSubTopic01.Text = eData.sMqttSubTopic1;
                tbMqttSubTopic02.Text = eData.sMqttSubTopic2;
                tbMqttPubTopic01.Text = eData.sMqttPubTopic1;
                tbMqttPubTopic02.Text = eData.sMqttPubTopic2;
                tbMqttPubPrefix.Text = eData.sMqttPrefix;
                tbMqttPubSuffix.Text = eData.sMqttSuffix;
                tbNotifyMsg.Text = eData.sNotifyMsg;


                tbLineApi01.Text = eData.sLineApi01;
                tbLineToken01.Text = eData.sLineToken01;
                tbLineToken02.Text = eData.sLineToken02;
                tbLineToken03.Text = eData.sLineToken03;
                tbLineToken04.Text = eData.sLineToken04;
                tbLineToken05.Text = eData.sLineToken05;
                tbTeleId01.Text = eData.sTelegramId01;
                tbTeleId02.Text = eData.sTelegramId02;
                tbTeleId03.Text = eData.sTelegramId03;
                tbTeleId04.Text = eData.sTelegramId04;
                tbTeleId05.Text = eData.sTelegramId05;
                tbTeleToken01.Text = eData.sTelegramToken01;
                tbTeleToken02.Text = eData.sTelegramToken02;
                tbTeleToken03.Text = eData.sTelegramToken03;
                tbTeleToken04.Text = eData.sTelegramToken04;
                tbTeleToken05.Text = eData.sTelegramToken05;

            }
            else
            {
                eData = new EnvData();
                eData.sId = tbId.Text;
                eData.sPwd = tbPwdRight.Text;
                eData.sServiceCode = tbServiceCode.Text;
                eData.sCharateristics = tbCharateristicsCode.Text;
                eData.sLineApi = tbLineApi.Text;
                eData.sLineToken = tbLineToken.Text;
                eData.sTelegramId = tbTeleId.Text;
                eData.sTelegramToken = tbTeleToken.Text;
                eData.sMqttServer = tbMqttServer.Text;
                eData.sMqttPubTopic1 = tbMqttPubTopic01.Text;
                eData.sMqttPubTopic2 = tbMqttPubTopic02.Text;
                eData.sMqttSubTopic1 = tbMqttSubTopic01.Text;
                eData.sMqttSubTopic2 = tbMqttSubTopic02.Text;
                eData.sMqttPrefix = tbMqttPubPrefix.Text;
                eData.sMqttSuffix = tbMqttPubSuffix.Text;
                eData.sNotifyMsg = tbNotifyMsg.Text;


                tbLineApi01.Text = eData.sLineApi01;
                tbLineToken01.Text = eData.sLineToken01;
                tbLineToken02.Text = eData.sLineToken02;
                tbLineToken03.Text = eData.sLineToken03;
                tbLineToken04.Text = eData.sLineToken04;
                tbLineToken05.Text = eData.sLineToken05;
                tbTeleId01.Text = eData.sTelegramId01;
                tbTeleId02.Text = eData.sTelegramId02;
                tbTeleId03.Text = eData.sTelegramId03;
                tbTeleId04.Text = eData.sTelegramId04;
                tbTeleId05.Text = eData.sTelegramId05;
                tbTeleToken01.Text = eData.sTelegramToken01;
                tbTeleToken02.Text = eData.sTelegramToken02;
                tbTeleToken03.Text = eData.sTelegramToken03;
                tbTeleToken04.Text = eData.sTelegramToken04;
                tbTeleToken05.Text = eData.sTelegramToken05;


                JsonSerialize.SaveEnvDataJson(eData, sSite);
            }






            BrokerAddress = "broker.emqx.io";
            ConnectMqtt();

            //client.Publish(saPubTopic[0], Encoding.UTF8.GetBytes($"{sSite} MQTT is Starting!"), 0, false);
            //client.Publish(saPubTopic[0], Encoding.UTF8.GetBytes(":-)"), 0, false);
            int nTemp = client.Publish(saPubTopic[0], Encoding.UTF8.GetBytes("000"), 0, false);
            client.Publish(saPubTopic[0], Encoding.UTF8.GetBytes("000"), 0, false);
            //MessageBox.Show(nTemp.ToString());

            dtMsgLineOldTime = DateTime.Now;
            dtMsgTeleOldTime= DateTime.Now;
            dtSaveOldTime = DateTime.Now;
        }

        private void ConnectMqtt()
        {

            client = new MqttClient(BrokerAddress);
            
            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            //client.Connect(clientId);

            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            try
            {
                client.Connect(clientId);
                if (client.IsConnected)
                {
                    lblMqttState.Text.Replace("Connected!", "");
                    lblMqttState.Text += "Connected!";

                    btnAcknowledgeAlarm.BackColor = Color.White;
                }
            }
            catch (Exception ex)
            {

                lblMqttState.Text.Replace("Failed Conn!", "");
                lblMqttState.Text += "Failed Conn!";
                lblMqttState.BackColor = Color.Black;
            }

            if (tbMqttSubTopic02.Text.Trim() == "")
            {
                byte[] baQos = { 0 };
                string[] saSubTopic = { tbMqttSubTopic01.Text };
                client.Subscribe(saSubTopic, baQos);
            }
            else
            {
                byte[] baQos = { 0, 0 };
                string[] saSubTopic = { tbMqttSubTopic01.Text, tbMqttSubTopic02.Text };
                client.Subscribe(saSubTopic, baQos);
            }
            //client.Subscribe(sSubTopic, bQos);
        }

        private void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string sReceivedMessage = Encoding.UTF8.GetString(e.Message);
            double dTemp;
            if (sReceivedMessage == "CheckOnLine" || sReceivedMessage == "CheckOffLine")
            {
                return;
            }

            if (double.TryParse(sReceivedMessage, out dTemp))
            {
                return;
            }

            if (bBtnSendMsg)
            {
                bBtnSendMsg = false;
                return;
            }




            if (sReceivedMessage == "ack")
            {
                btnAcknowledgeAlarm.Text = "ACK Alarm";
                //btnAcknowledgeAlarm.Text = "Return";
                bAcknowlodge = !bAcknowlodge;
            }
            if(sReceivedMessage == "return")
            {
                //btnAcknowledgeAlarm.Text = "ACK Alarm";
                bAcknowlodge = !bAcknowlodge;
                btnAcknowledgeAlarm.Text = "Return";
            }
        }

        private void StartBleDeviceWatcher()
        {
            string[] requestedProperties = { "System.Devices.Aep.DeviceAddress", "System.Devices.Aep.IsConnected", "System.Devices.Aep.Bluetooth.Le.IsConnectable" };

            string aqsAllBluetoothLEDevices = "(System.Devices.Aep.ProtocolId:=\"{bb7bb05e-5972-42b5-94fc-76eaa7084d49}\")";

            deviceWatcher =
                    DeviceInformation.CreateWatcher(
                        aqsAllBluetoothLEDevices,
                        requestedProperties,
                        DeviceInformationKind.AssociationEndpoint);

            // Register event handlers before starting the watcher.
            deviceWatcher.Added += DeviceWatcher_Added;
            deviceWatcher.Updated += DeviceWatcher_Updated;
            deviceWatcher.Removed += DeviceWatcher_Removed;
            deviceWatcher.EnumerationCompleted += DeviceWatcher_EnumerationCompleted;
            deviceWatcher.Stopped += DeviceWatcher_Stopped;

            // Start over with an empty collection.
            _knownDevices.Clear();
            deviceWatcher.Start();
        }

        public void Respond(string message)
        {
            //if (rtbResponse.Text != "")
            //{
            //    rtbResponse.AppendText(Environment.NewLine + Environment.NewLine);
            //}
            //rtbResponse.Clear();
            //rtbResponse.AppendText(message);
            //rtbResponse.ScrollToCaret();
        }

        private void DeviceWatcher_Added(DeviceWatcher sender, DeviceInformation deviceInfo)
        {
            //Debug.WriteLine(String.Format("Device Found!" + Environment.NewLine + "ID:{0}" + Environment.NewLine + "Name:{1}", deviceInfo.Id, deviceInfo.Name));

            //notify user for every device that is found
            Respond(String.Format("Device Found!" + Environment.NewLine + "ID:{0}" + Environment.NewLine + "Name:{1}", deviceInfo.Id, deviceInfo.Name));

            if (sender == deviceWatcher)
            {
                if (!_knownDevices.Contains(deviceInfo))
                {
                    if (deviceInfo.Id != string.Empty && deviceInfo.Name.ToLower().Contains(cbBleName.Text.ToLower()))
                    {
                        _knownDevices.Add(deviceInfo);
                        cbScanedDevice.Items.Add(deviceInfo.Name.Replace("Bluetooth ", "") + " : " + deviceInfo.Id);
                    }
                    else if (deviceInfo.Id != string.Empty && cbBleName.SelectedIndex != 0)
                    {
                        _knownDevices.Add(deviceInfo);
                        cbScanedDevice.Items.Add(deviceInfo.Name.Replace("Bluetooth ", "") + " : " + deviceInfo.Id);
                    }
                    else
                    {
                        UnknownDevices.Add(deviceInfo);
                    }
                }
            }
        }


        private void DeviceWatcher_Updated(DeviceWatcher sender, DeviceInformationUpdate deviceInfo)
        {
            foreach (var device in _knownDevices)
            {
                if (device.Id == deviceInfo.Id)
                {
                    //Respond(device.Id + " Updated");
                    return;
                }
            }
            //Respond(deviceInfo.Id + " Updated");
        }


        private void DeviceWatcher_Removed(DeviceWatcher sender, DeviceInformationUpdate deviceInfo)
        {
            foreach (var device in _knownDevices)
            {
                // Id = "BluetoothLE#BluetoothLEa8:3b:76:29:0b:9e-47:40:9b:dc:fe:06"
                if (device.Id == deviceInfo.Id)
                {
                    Respond(device.Id + " Removed");
                    //cbScanedDevice.Items.Remove(device.Id);
                    cbScanedDevice.Items.Remove(device.Name.Replace("Bluetooth ", "") + " : " + device.Id);
                    _knownDevices.Remove(device);
                    return;
                }
            }
            //Respond(deviceInfo.Id + " Removed");
        }


        private void DeviceWatcher_EnumerationCompleted(DeviceWatcher sender, object args)
        {
            //Respond("Device Enumeration Completed");
            btnScan.Enabled = true;
        }


        private void DeviceWatcher_Stopped(DeviceWatcher sender, object args)
        {
            //Respond(args.ToString() + " Stopped");
            btnScan.Enabled = true;
            //Respond("Stoped Scanning");
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void cbScanedDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbScanedDevice.SelectedIndex != -1)
            {
                bIsConnected = false;
                btnConnect.Enabled = true;
            }
        }


        private async void ConnectDevice(DeviceInformation deviceInfo)
        {
            Respond("Connecting to device...");

            //get bluetooth device information
            BluetoothLEDevice bluetoothLeDevice = await BluetoothLEDevice.FromIdAsync(deviceInfo.Id);
            //Respond(bluetoothLeDevice.ConnectionStatus.ToString());

            //get its services
            GattDeviceServicesResult result = await bluetoothLeDevice.GetGattServicesAsync();

            //verify if getting success 
            if (result.Status == GattCommunicationStatus.Success)
            {
                //store device services to list
                services = result.Services;
                List<String> lstServiceName = new List<String>();
                List<String> lstGattCharacteristicsResult = new List<String>();
                List<String> lstresultCharacterics = new List<String>();
                List<String> lstCharUUid = new List<String>();

                richTextBox1.Text += "\n=========================================" + Environment.NewLine;
                richTextBox1.Text += "\n=========================================" + Environment.NewLine;

                //loop each services in list
                foreach (var serv in services)
                {
                    //get serviceName by converting the service UUID
                    // serv.Uuid = {0000fff0-0000-1000-8000-00805f9b34fb}
                    // ServiceName = "65520"  => 0xFFF0
                    //string ServiceName = Utilities.ConvertUuidToShortId(serv.Uuid).ToString();
                    richTextBox1.Text += "Service Code Set Value : \n" +tbServiceCode.Text + Environment.NewLine;
                    richTextBox1.Text += "Charatersitic Code Set Value : \n" + tbCharateristicsCode.Text + Environment.NewLine;
                    richTextBox1.Text += "=========================================\n"+Environment.NewLine;
                    string ServiceName = Utilities.ConvertUuidToShortId(serv.Uuid).ToString("x");
                    lstServiceName.Add(ServiceName);
                    richTextBox1.Text += "\n Service Uuid :"+ serv.Uuid.ToString()+ "\n ServiceName  : " + ServiceName+"\n";



                    //if current servicename matches the input service name
                    if (ServiceName == tbServiceCode.Text.ToLower())
                    {
                        //notify the user that it found the service
                        Respond("Service found...");

                        //store the current service
                        // Uuid = {0000fff0-0000-1000-8000-00805f9b34fb}
                        currentSelectedService = serv;

                        //get the current service characteristics
                        GattCharacteristicsResult resultCharacterics = await serv.GetCharacteristicsAsync();
                        lstGattCharacteristicsResult.Add(resultCharacterics.ToString());
                        richTextBox1.Text += "\n GattCharacteristicsResult  : " + resultCharacterics.ToString();

                        //verify if getting characteristics is success 
                        if (resultCharacterics.Status == GattCommunicationStatus.Success)
                        {
                            //store device services to list
                            characteristics = resultCharacterics.Characteristics;
                            lstresultCharacterics.Add(characteristics.ToString());
                            richTextBox1.Text += "\n resultCharacterics.Characteristics  : " + resultCharacterics.ToString();


                            //loop through its characteristics
                            foreach (var chara in characteristics)
                            {
                                // Uuid = {0000fff4-0000-1000-8000-00805f9b34fb}
                                //get CharacteristicName by converting the current characteristic UUID
                                //string CharacteristicName = Utilities.ConvertUuidToShortId(chara.Uuid).ToString();
                                string CharacteristicName = Utilities.ConvertUuidToShortId(chara.Uuid).ToString("x");
                                lstCharUUid.Add(CharacteristicName);
                                richTextBox1.Text += "\n CharacteristicName chara.UUid  : " + chara.Uuid.ToString();
                                richTextBox1.Text += "\n CharacteristicName(chara.UUid)  : " + resultCharacterics.ToString();
                                richTextBox1.Text += "\n----------------------------------------------" + Environment.NewLine;
                                //richTextBox1.Text += "\n=========================================" + Environment.NewLine;



                                //if current CharacteristicName matches the input characteristic name
                                // CharacteristicName = "65524"  => FFF4
                                if (CharacteristicName == tbCharateristicsCode.Text.ToLower())
                                {
                                    //notify the user that it found the characteristicName
                                    Respond("Characteristic found...");

                                    //store the current characteristic
                                    currentSelectedCharacteristic = chara;

                                    //notify the user that it has connected successfully to the device
                                    Respond("Connected Successfully!");
                                    bIsConnected = true;
                                    btnMeasement.Enabled = true;
                                    MessageBox.Show("Connected Successfully!");

                                    //stop method execution
                                    return;
                                }
                            }
                            //notify that no characteristicname matched the input characteristic
                            Respond("Characteristic not found...");
                        }
                        else
                        {
                            //notify the user that it has problem getting current service characteristics
                            Respond("Unable to get device service characterics!");
                        }
                    }
                }
                //notify that no servicename matched the input service
                Respond("Service not found...");
            }
            else
            {
                //notify the user that it has problem getting its services
                Respond("Unable to get device services!");
            }

        }


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            cbScanedDevice.Items.Clear();
            _knownDevices.Clear();
            UnknownDevices.Clear();
            cbScanedDevice.SelectedIndex = -1;

            Respond("Scanning nearny Ble Devices ...");

            btnScan.Enabled = false;
            StartBleDeviceWatcher();
            btnStopScan.Enabled = true;
            btnConnect.Enabled = false;
            btnMeasement.Enabled = false;
        }

        private void btnStopScan_Click(object sender, EventArgs e)
        {
            deviceWatcher.Stop();
            btnScan.Enabled = true;
            Respond("Stoped Scanning");
            btnStopScan.Enabled = false;
        }

        private async void btnMeasement_Click(object sender, EventArgs e)
        {
            Thread thDoMeasure = new Thread(DoMeasure);
            thDoMeasure.Start();
            btnAcknowledgeAlarm.Enabled = true;
            btnStopMeasure.Enabled = true;

            Thread thAutoCheckSms = new Thread(AutoCheckSms);
            thAutoCheckSms.Start();
        }
        public async void AutoCheckSms()
        {
            dtAutoSendOldTime = DateTime.Now;
            dtMsgLineOldTime = DateTime.Now;
            dtMsgTeleOldTime = DateTime.Now;

            //iAutoSendSmsSec = int.Parse(nudAutoSendSms.Value.ToString());



            while (cbAutoSmsCheck.Checked)
            {
                //iAutoSendSmsSec = int.Parse(nudAutoSendSms.Value.ToString());
                iAutoSendSmsSec = (int)nudAutoSendSms.Value;


                TimeSpan tsDiff = DateTime.Now - dtAutoSendOldTime;

                if (tsDiff.TotalSeconds > iAutoSendSmsSec)
                {
                    
                    dtAutoSendOldTime = DateTime.Now;

                    TimeSpan tsLineListDiff = DateTime.Now - dtLineListOldTime;
                    if (tsLineListDiff.TotalSeconds > 300)
                    {
                        dtLineListOldTime = DateTime.Now;
                        //List<TextBox> lstTbLineApi, lstTbLineToken;
                        MakeMemberLineList(out lstTbLineApi, out lstTbLineToken);
                    }

                    for (int i = 0; i < lstTbLineToken.Count; i++)
                    {
                        if (!bAcknowlodge && lstTbLineToken[i].Text.Trim() != "")
                        {
                            SendLineMsg(lstTbLineApi[i].Text, lstTbLineToken[i].Text, ("\n\n [" + sSite + "]\n Member " + i.ToString("00") + " \n\n OnLine Check" + "!"));
                            Thread.Sleep(500);
                        }
                    }


                    TimeSpan tsTeleListDiff = DateTime.Now - dtTeleListOldTime;
                    if (tsTeleListDiff.TotalSeconds > 300)
                    {
                        dtTeleListOldTime = DateTime.Now;

                        //List<TextBox> lstTbTeleToken, lstTbTeleId;
                        MakeMemberTelegramList(out lstTbTeleToken, out lstTbTeleId);
                    }

                    for (int i = 0; i < 6; i++)
                    {
                        if (!bAcknowlodge && lstTbTeleToken[i].Text.Trim() != "")
                        {
                            SendTeleMessage(lstTbTeleToken[i].Text, lstTbTeleId[i].Text, ("\n\n [" + sSite + "]\n Member " + i.ToString("00") + " \n\n OnLine Check" + "!"));
                            Thread.Sleep(500);
                        }
                    }


                    client.Publish(tbMqttPubTopic02.Text, Encoding.UTF8.GetBytes("CheckOnLine"), 0, false);

                }
            }
        }

        public float MeasureConvertToFloat(byte[] nums)
        {
            // check if temp is negative
            int num = (nums[1] << 8) | nums[0];
            if (nums[1] == 0xff)
            {
                num = -((num ^ 0xffff) + 1);
            }
            return Convert.ToSingle(num) / 100;
        }
        public async void DoMeasure()
        {
            if (cbScanedDevice.SelectedIndex == -1)
            {
                MessageBox.Show("Select a Device First");
                return;
            }

            dtOldTime = DateTime.Now;
            dtLineListOldTime = DateTime.Now;
            dtTeleListOldTime = DateTime.Now;

            btnMeasement.Enabled = false;
            btnStopMeasure.Enabled = true;
            bDoMeasure = true;

            while (bDoMeasure)
            {
                var vConnected = client.IsConnected;
                if (!vConnected)
                {
                    ConnectMqtt();
                }

                lFrequency = long.Parse(nudCycleTime.Value.ToString());
                TimeSpan tsDiff = DateTime.Now - dtOldTime;

                if (tsDiff.TotalSeconds > lFrequency)
                {
                    dtOldTime = DateTime.Now;
                    lblDateTimeNow.Text = DateTime.Now.ToString();
                    rtbResponse.Clear();

                    if (currentSelectedService != null && currentSelectedCharacteristic != null)
                    {
                        GattCharacteristicProperties properties = currentSelectedCharacteristic.CharacteristicProperties;

                        //if selected characteristics has read property
                        if (properties.HasFlag(GattCharacteristicProperties.Read))
                        {
                            //read value asynchronously
                            GattReadResult result = await currentSelectedCharacteristic.ReadValueAsync();
                            if (result.Status == GattCommunicationStatus.Success)
                            {
                                var reader = DataReader.FromBuffer(result.Value);
                                byte[] input = new byte[reader.UnconsumedBufferLength];
                                reader.ReadBytes(input);

                                float fValue = MeasureConvertToFloat(input);
                                string sOut = "";

                                
                                richTextBox1.Text = fValue.ToString()+ "\n#######################\n"+ richTextBox1.Text;

                                foreach (var item in input)
                                {
                                    sOut += item.ToString("x");
                                    //sOut+= " ";
                                }

                                richTextBox1.Text= sOut + "\n#######################\n" + richTextBox1.Text;

                                return;
                                foreach (var item in input)
                                {
                                    sOut += item.ToString("x");
                                    //sOut+= " ";
                                }
                                //if (sOut != "")
                                //{
                                //    //rtbResponse.AppendText(Environment.NewLine + Environment.NewLine);
                                //}
                                ////rtbResponse.AppendText(sOut);
                                //if (sOut != "")
                                //{
                                //    //rtbResponse.AppendText(Environment.NewLine + Environment.NewLine);
                                //}
                                //rtbResponse.ScrollToCaret();

                                //Respond(Encoding.ASCII.GetString(input));
                                //Respond(Encoding.UTF8.GetString(input));
                                //Respond(Encoding.Unicode.GetString(input));

                                string sType = "";
                                sType = Decoder.CheckType.Type(sOut);

                                if (sType == "3")
                                {
                                    //rtbResponse.AppendText("Checked Type 3");

                                    //rtbResponse.AppendText(Environment.NewLine + Environment.NewLine);

                                    //rtbResponse.AppendText("Start Decoding....");


                                    string sMeasure = "";
                                    List<string> lstFuncUnit = new List<string>();

                                    sMeasure = DecodingType3.printdigit(DecodingType3.decode(sOut));
                                    // sFuncUnit = "27"
                                    lstFuncUnit = DecodingType3.printchar(DecodingType3.decode(sOut));
                                    //sOut = "1b847251a261bf7b66a2"
                                    //
                                    //lstsMeasure = Count = 2
                                    //String
                                    // Flash,  °C
                                    //

                                    //rtbResponse.AppendText(Environment.NewLine);
                                    //rtbResponse.AppendText("====================================");
                                    //rtbResponse.AppendText(Environment.NewLine);
                                    //rtbResponse.AppendText(lstFuncUnit[0]);
                                    //lblMode.Text = lstFuncUnit[0];
                                    //rtbResponse.AppendText(Environment.NewLine);
                                    //rtbResponse.AppendText(sMeasure + " " + lstFuncUnit[1]);
                                    //lblValue.Text = sMeasure;
                                    //lblUnit.Text = lstFuncUnit[1];

                                    //if (sMeasure == "0L." || sMeasure == "Auto" || sMeasure == ".0L")
                                    //{
                                    //    sMeasure = "99999";
                                    //}                                   
                                    //double dMeasure = double.Parse(sMeasure);
                                    double dMeasure = 99999;
                                    //double.TryParse(sMeasure, out dMeasure);
                                    if(double.TryParse(sMeasure, out dMeasure) && cbPt100.Checked)
                                    {
                                        double dPt100CF = 0.39083;
                                        double dPt100OffSet = 0.100;
                                        double.TryParse(tbPt100Cf.Text, out dPt100CF);
                                        double.TryParse(tbPt100OffSet.Text, out dPt100OffSet);
                                        dMeasure = (dMeasure - dPt100OffSet) / dPt100CF;
                                        sMeasure = dMeasure.ToString("0.00");
                                        lstFuncUnit[0] = lstFuncUnit[0].Replace("k", "PT100");
                                        lstFuncUnit[1] = lblUnit.Text.Replace("Ω", "°C");
                                    }
                                    lblMode.Text = lstFuncUnit[0];
                                    lblValue.Text = sMeasure;
                                    lblUnit.Text = lstFuncUnit[1];


                                    aGauge1.Value = (float)dMeasure;


                                    //Invoke(new Action(() =>
                                    //{
                                    //    richTextBox1.Text += sReceivedMsg;
                                    //}));
                                    Invoke(new Action(() =>
                                    {
                                        ListViewItem lvi = new ListViewItem();
                                        lvi.Text = DateTime.Now.ToString();
                                        lvi.SubItems.Add(sMeasure);
                                        lvi.SubItems.Add(lstFuncUnit[1]);

                                        //int nLimitCount = 3600 * 12; // 1h display => the one file is saved every each day!! then 24 hour 
                                        // int nLimitCount = 1200 * 24; /// 1time/3sec *24h display => the one file is saved every each day!! then 24 hour 
                                        //int nLimitCount = 5; // 1time/3sec *24h display => the one file is saved every each day!! then 24 hour 
                                        int nLimitCount = 3600 * 24;  // Invoke retry!!!
                                        if (lvData.Items.Count > nLimitCount)
                                        {
                                            lvData.Items[nLimitCount].Remove();
                                        }
                                        lvData.Items.Add(lvi);

                                        if (chTrend.Series[0].Points.Count > nLimitCount)
                                        {
                                            chTrend.Series[0].Points.RemoveAt(0);
                                        }
                                        chTrend.Series[0].Points.AddY(dMeasure);

                                    }));



                                    if (ckbOnMqttPub.Checked)
                                    {
                                        //brokeraddress = tbmqttserver.text;
                                        //client = new mqttclient(brokeraddress);

                                        client.Publish(tbMqttPubTopic01.Text, Encoding.UTF8.GetBytes(tbMqttPubPrefix.Text + sMeasure + tbMqttPubSuffix.Text), 2, false);

                                        //saPubTopic[0] = tbMqttPubTopic01.Text;
                                        //saPubTopic[1] = tbMqttPubTopic02.Text;
                                        //for (int i = 0; i < saPubTopic.Length; i++)
                                        //{
                                        //    if (saPubTopic[i] != "")
                                        //    {
                                        //        //client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes("Measure : " + sMeasure), 0, false);
                                        //        //client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes(tbMqttPubPrefix.Text + sMeasure + tbMqttPubSuffix.Text), 0, false);
                                        //        //client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes(tbMqttPubPrefix.Text + sMeasure + tbMqttPubSuffix.Text), 1, false);
                                        //        try
                                        //        {
                                        //            client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes(tbMqttPubPrefix.Text + sMeasure + tbMqttPubSuffix.Text), 2, false);
                                        //        }
                                        //        catch (Exception ex)
                                        //        {
                                        //            lblMqttState.Text = ex.Message;
                                        //            //throw;
                                        //        }
                                        //        //client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes(tbMqttPubPrefix.Text + dMeasure.ToString() + tbMqttPubSuffix.Text), 0, false);
                                        //    }
                                        //}
                                    }

                                    float fNormalMax = 0.0f;
                                    float fNormalMin = 0.0f;
                                    float.TryParse(tbNormalMaxValue.Text, out fNormalMax);
                                    float.TryParse(tbNormalMinValue.Text, out fNormalMin);
                                    TimeSpan tsMsgLineDiff = DateTime.Now - dtMsgLineOldTime;

                                    bool bIsOnLineAlarm = ckbAlarmLineSms.Checked;
                                    if (bIsOnLineAlarm && (dMeasure > fNormalMax) && (tsMsgLineDiff.TotalSeconds > iAlarmTimeSec))
                                    {
                                        dtMsgLineOldTime = DateTime.Now;

                                        TimeSpan tsLineListDiff = DateTime.Now - dtLineListOldTime;
                                        if (tsLineListDiff.TotalSeconds > 300)
                                        {
                                            dtLineListOldTime = DateTime.Now;
                                            //List<TextBox> lstTbLineApi, lstTbLineToken;
                                            MakeMemberLineList(out lstTbLineApi, out lstTbLineToken);
                                        }

                                        for (int i = 0; i < 6; i++)
                                        {
                                            if (!bAcknowlodge && lstTbLineToken[i].Text.Trim() != "")
                                            {
                                                SendLineMsg(lstTbLineApi[i].Text, lstTbLineToken[i].Text, ("\n\n [" + sSite + "]\n Member " + i.ToString("00") + " \n\n Alarm : " + sMeasure + " " + lstFuncUnit[1] + "\n\n Over than " + fNormalMax + "!!!"));
                                                Thread.Sleep(500);
                                            }
                                        }

                                    }
                                    else if (bIsOnLineAlarm && (dMeasure < fNormalMin) && (tsMsgLineDiff.TotalSeconds > iAlarmTimeSec))
                                    {
                                        dtMsgLineOldTime = DateTime.Now;

                                        TimeSpan tsLineListDiff = DateTime.Now - dtLineListOldTime;
                                        if (tsLineListDiff.TotalSeconds > 300)
                                        {
                                            dtLineListOldTime = DateTime.Now;
                                            //List<TextBox> lstTbLineApi, lstTbLineToken;
                                            MakeMemberLineList(out lstTbLineApi, out lstTbLineToken);
                                        }

                                        for (int i = 0; i < lstTbLineToken.Count; i++)
                                        {
                                            if (!bAcknowlodge && lstTbLineToken[i].Text.Trim() != "")
                                            {
                                                SendLineMsg(lstTbLineApi[i].Text, lstTbLineToken[i].Text, ("\n\n [" + sSite + "]\n Member " + i.ToString("00") + " \n\n Alarm : " + sMeasure + " " + lstFuncUnit[1] + "\n\n Less than " + fNormalMin + "!!!"));
                                                Thread.Sleep(500);
                                            }
                                        }

                                        //SendLineMsg((sSite + " Alarm : " + sMeasure + " " + lstFuncUnit[1] + " less than " + fNormalMin + "!!!"));


                                    }
                                    //rtbResponse.AppendText(Environment.NewLine);

                                    sTeleId = tbTeleId.Text;
                                    sTeleToken = tbTeleToken.Text;
                                    bool bIsOnTeleAlarm = ckbAlarmTeleSms.Checked;
                                    TimeSpan tsMsgTeleDiff = DateTime.Now - dtMsgTeleOldTime;

                                    if (bIsOnTeleAlarm && (dMeasure > fNormalMax) && (tsMsgTeleDiff.TotalSeconds > iAlarmTimeSec))
                                    {
                                        dtMsgTeleOldTime = DateTime.Now;

                                        TimeSpan tsTeleListDiff = DateTime.Now - dtTeleListOldTime;
                                        if (tsTeleListDiff.TotalSeconds > 300)
                                        {
                                            dtTeleListOldTime = DateTime.Now;

                                            //List<TextBox> lstTbTeleToken, lstTbTeleId;
                                            MakeMemberTelegramList(out lstTbTeleToken, out lstTbTeleId);
                                        }

                                        for (int i = 0; i < 6; i++)
                                        {
                                            if (!bAcknowlodge && lstTbTeleToken[i].Text.Trim() != "")
                                            {
                                                SendTeleMessage(lstTbTeleToken[i].Text, lstTbTeleId[i].Text, ("\n\n [" + sSite + "]\n Member " + i.ToString("00") + " \n\n Alarm : " + sMeasure + " " + lstFuncUnit[1] + "\n\n Over than " + fNormalMax + "!!!"));
                                                Thread.Sleep(500);
                                            }
                                        }

                                    }
                                    else if (bIsOnTeleAlarm && (dMeasure < fNormalMin) && (tsMsgTeleDiff.TotalSeconds > iAlarmTimeSec))
                                    {
                                        dtMsgTeleOldTime = DateTime.Now;

                                        TimeSpan tsTeleListDiff = DateTime.Now - dtTeleListOldTime;
                                        if (tsTeleListDiff.TotalSeconds > 300)
                                        {
                                            dtTeleListOldTime = DateTime.Now;

                                            //List<TextBox> lstTbTeleToken, lstTbTeleId;
                                            MakeMemberTelegramList(out lstTbTeleToken, out lstTbTeleId);
                                        }

                                        for (int i = 0; i < 6; i++)
                                        {
                                            if (!bAcknowlodge && lstTbTeleToken[i].Text.Trim() != "")
                                            {
                                                SendTeleMessage(lstTbTeleToken[i].Text, lstTbTeleId[i].Text, ("\n\n [" + sSite + "]\n Member " + i.ToString("00") + " \n\n Alarm : " + sMeasure + " " + lstFuncUnit[1] + "\n\n Less than " + fNormalMin + "!!!"));
                                                Thread.Sleep(500);
                                            }
                                        }
                                    }


                                    //rtbResponse.AppendText("====================================");
                                    //rtbResponse.AppendText(Environment.NewLine);
                                    //rtbResponse.ScrollToCaret();

                                    AutoSaveDataFile();

                                }
                            }
                            else
                            {
                                Respond("Error encountered on reading characteristic value!");
                            }
                        }
                        else
                        {
                            Respond("No read property for this characteristic!");
                        }
                    }
                    else
                    {
                        Respond("Please connect to a device first!");
                    }
                }
            }
        }

        private void MakeMemberTelegramList(out List<TextBox> lstTbTeleToken, out List<TextBox> lstTbTeleId)
        {
            lstTbTeleId = new List<TextBox>();
            lstTbTeleToken = new List<TextBox>();
            lstTbTeleToken.Clear();
            lstTbTeleToken.Add(tbTeleToken);
            lstTbTeleToken.Add(tbTeleToken01);
            lstTbTeleToken.Add(tbTeleToken02);
            lstTbTeleToken.Add(tbTeleToken03);
            lstTbTeleToken.Add(tbTeleToken04);
            lstTbTeleToken.Add(tbTeleToken05);
            lstTbTeleId.Clear();
            lstTbTeleId.Add(tbTeleId);
            lstTbTeleId.Add(tbTeleId01);
            lstTbTeleId.Add(tbTeleId02);
            lstTbTeleId.Add(tbTeleId03);
            lstTbTeleId.Add(tbTeleId04);
            lstTbTeleId.Add(tbTeleId05);
        }

        private void MakeMemberLineList(out List<TextBox> lstTbLineApi, out List<TextBox> lstTbLineToken)
        {
            lstTbLineApi = new List<TextBox>();
            lstTbLineToken = new List<TextBox>();
            lstTbLineApi.Clear();
            lstTbLineApi.Add(tbLineApi);
            for (int i = 0; i < 5; i++)
            {
                lstTbLineApi.Add(tbLineApi01);
            }
            lstTbLineToken.Clear();
            lstTbLineToken.Add(tbLineToken);
            lstTbLineToken.Add(tbLineToken01);
            lstTbLineToken.Add(tbLineToken02);
            lstTbLineToken.Add(tbLineToken03);
            lstTbLineToken.Add(tbLineToken04);
            lstTbLineToken.Add(tbLineToken05);
        }

        public void SendLineMsg(string sLineApi, string sLineToken, string sMsg)
        {
            WebClient wc = new WebClient();
            //string api_server = tbLineApi.Text;
            string api_server = sLineApi;

            //wc.Headers["Authorization"] = "Bearer <토큰>";
            //wc.Headers["Authorization"] = "Bearer " + tbLineToken.Text;
            wc.Headers["Authorization"] = "Bearer " + sLineToken;

            NameValueCollection nvc = new NameValueCollection();
            //nvc["message"] = "Line Notify Test~~";
            nvc["message"] = sMsg;

            byte[] response_stream = wc.UploadValues(api_server, nvc);
            string response = Encoding.UTF8.GetString(response_stream);

            //rtbResponse.AppendText(response + Environment.NewLine);
        }

        private void btnStopMeasure_Click(object sender, EventArgs e)
        {
            btnMeasement.Enabled = true;
            btnStopMeasure.Enabled = false;
            bDoMeasure = false;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (cbScanedDevice.SelectedIndex != -1 && tbServiceCode.Text != "" && tbCharateristicsCode.Text != "")
            {
                //start connecting to device
                ConnectDevice(_knownDevices[cbScanedDevice.SelectedIndex]);
                if (bIsConnected)
                {
                    btnMeasement.Enabled = true;
                }
            }
            else
            {
                //conditions not met
                //Respond("Please select a device and fill up characterics and services textbox!");
            }
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnLineNotify_Click(object sender, EventArgs e)
        {
            sTeleId = tbTeleId.Text;
            sTeleToken = tbTeleToken.Text;

            lFrequency = long.Parse(nudCycleTime.Value.ToString());
            TimeSpan tsMsgDiff = DateTime.Now - dtMsgLineOldTime;

            if (tsMsgDiff.TotalSeconds > lFrequency && tsMsgDiff.TotalSeconds > 10)
            {
                dtMsgLineOldTime = DateTime.Now;
                //SendTeleMessage(sTeleId, tbNotifyMsg.Text);
                //SendLineMsg(tbNotifyMsg.Text);

                List<TextBox> lstTbLineApi, lstTbLineToken;
                MakeMemberLineList(out lstTbLineApi, out lstTbLineToken);

                for (int i = 0; i < 6; i++)
                {
                    if (lstTbLineToken[i].Text.Trim() != "")
                    {
                        SendLineMsg(lstTbLineApi[i].Text, lstTbLineToken[i].Text, ("Member [" + i.ToString("00") + "] : " + tbNotifyMsg.Text));
                        Thread.Sleep(500);
                    }
                }

                List<TextBox> lstTbTeleToken, lstTbTeleId;
                MakeMemberTelegramList(out lstTbTeleToken, out lstTbTeleId);

                for (int i = 0; i < 6; i++)
                {
                    if (lstTbTeleToken[i].Text.Trim() != "")
                    {
                        SendTeleMessage(lstTbTeleToken[i].Text, lstTbTeleId[i].Text, ("Member [" + i.ToString("00") + "] : " + tbNotifyMsg.Text));
                        Thread.Sleep(500);
                    }
                }
            }
        }

        public async Task SendTeleMessage(string sTeleToken, string sDestId, string sMsg)
        {
            try
            {
                var bot = new Telegram.Bot.TelegramBotClient(sTeleToken);
                await bot.SendTextMessageAsync(sDestId, sMsg);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message);
                //Console.WriteLine("Error : "+ex.Message);
            }
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
            DateTime dtMsgOldTime = DateTime.Now;
        }

        private void btnSaveCsv_Click(object sender, EventArgs e)
        {
            SaveFileDialog savedialog = new SaveFileDialog();
            savedialog.Filter = "csv fiels (*.csv)|*.csv|All files (*.*)|*.*";
            savedialog.FilterIndex = 0;
            savedialog.RestoreDirectory = true;

            if (savedialog.ShowDialog() == DialogResult.OK)
            {
                var builder = new StringBuilder();
                for (int i = 0; i < lvData.Items.Count; i++)
                {
                    builder.Append(lvData.Items[i].SubItems[0].Text + ",");
                    builder.Append(lvData.Items[i].SubItems[1].Text + ",");
                    builder.Append(lvData.Items[i].SubItems[2].Text + "\n");
                }
                File.WriteAllText(savedialog.FileName, builder.ToString(), Encoding.UTF8);
            }
        }

        private void ckbAutoSave_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chTrend_Click(object sender, EventArgs e)
        {

        }

        private void btnAcknowledgeAlarm_Click(object sender, EventArgs e)
        {
            bAcknowlodge = !bAcknowlodge;
            bBtnSendMsg = true;

            if (bAcknowlodge)
            {
                btnAcknowledgeAlarm.Text = "Return";
                client.Publish(tbMqttPubTopic02.Text, Encoding.UTF8.GetBytes("return"), 0, false);
                //if (ckbOnMqttPub.Checked)
                //{
                //    brokeraddress = tbmqttserver.text;
                //    client = new mqttclient(brokeraddress);

                //    saPubTopic[0] = tbMqttPubTopic01.Text;
                //    saPubTopic[1] = tbMqttPubTopic02.Text;


                //    for (int i = 0; i < saPubTopic.Length; i++)
                //    {
                //        if (saPubTopic[i] != "")
                //        {
                //            //client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes(tbMqttPubPrefix.Text + sMeasure + tbMqttPubSuffix.Text), 2, false);
                //            try
                //            {
                //                client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes("return"), 2, false);
                //            }
                //            catch (Exception ex)
                //            {
                //                lblMqttState.Text = ex.Message;
                //                //throw;
                //            }
                //        }

                //    }
                //}
            }
            else
            {
                btnAcknowledgeAlarm.Text = "ACK Alarm";
                client.Publish(tbMqttPubTopic02.Text, Encoding.UTF8.GetBytes("ack"), 0, false);
                //if (ckbOnMqttPub.Checked)
                //{
                //    saPubTopic[0] = tbMqttPubTopic01.Text;
                //    saPubTopic[1] = tbMqttPubTopic02.Text;
                //    for (int i = 0; i < saPubTopic.Length; i++)
                //    {
                //        if (saPubTopic[i] != "")
                //        {
                //            try
                //            {
                //                client.Publish(saPubTopic[i], Encoding.UTF8.GetBytes("ack"), 2, false);
                //            }
                //            catch (Exception ex)
                //            {
                //                lblMqttState.Text = ex.Message;
                //            }
                //        }

                //    }
                //}
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void AutoSaveDataFile()
        {
            TimeSpan tsMsgDiff = DateTime.Now - dtSaveOldTime;

            int nLimitSecond = 3600;
            nLimitSecond = int.Parse(nudAutoSave.Value.ToString());

            if (ckbAutoSave.Checked && tsMsgDiff.TotalSeconds > nLimitSecond)
            {
                dtSaveOldTime = DateTime.Now;

                string sYear = DateTime.Now.Year.ToString();
                string sMonth = DateTime.Now.Month.ToString("00");
                string sDay = DateTime.Now.Day.ToString("00");
                //string sFileDir = @"c:\TheSeaLab\Data\";
                string sFileDir = @"c:\TheSeaLab\" + sSite + "\\Data\\";

                var fileInfo = new FileInfo(sFileDir + sYear + "\\data_" + sYear + sMonth + sDay + ".csv");

                if (!fileInfo.Exists)
                {
                    Directory.CreateDirectory(fileInfo.DirectoryName);
                }
                var builder = new StringBuilder();
                for (int i = 0; i < lvData.Items.Count; i++)
                {
                    builder.Append(lvData.Items[i].SubItems[0].Text + ",");
                    builder.Append(lvData.Items[i].SubItems[1].Text + ",");
                    builder.Append(lvData.Items[i].SubItems[2].Text + "\n");
                }
                File.WriteAllText(fileInfo.FullName, builder.ToString(), Encoding.UTF8);
            }
        }

        private void btnSaveSettings_Click(object sender, EventArgs e)
        {
            if (tbPwdLeft.Text != tbPwdRight.Text)
            {
                MessageBox.Show("The password is not the same left and right.");
                return;
            }

            EnvData eData = new EnvData();
            eData.sId = tbId.Text;
            eData.sPwd = tbPwdRight.Text;
            eData.sServiceCode = tbServiceCode.Text;
            eData.sCharateristics = tbCharateristicsCode.Text;
            eData.sLineApi = tbLineApi.Text;
            eData.sLineToken = tbLineToken.Text;
            eData.sTelegramId = tbTeleId.Text;
            eData.sTelegramToken = tbTeleToken.Text;
            eData.sMqttServer = tbMqttServer.Text;
            eData.sMqttPubTopic1 = tbMqttPubTopic01.Text;
            eData.sMqttPubTopic2 = tbMqttPubTopic02.Text;
            eData.sMqttSubTopic1 = tbMqttSubTopic01.Text;
            eData.sMqttSubTopic2 = tbMqttSubTopic02.Text;
            eData.sMqttPrefix = tbMqttPubPrefix.Text;
            eData.sMqttSuffix = tbMqttPubSuffix.Text;
            eData.sNotifyMsg = tbNotifyMsg.Text;

            eData.sLineApi01 = tbLineApi01.Text;
            eData.sLineToken01 = tbLineToken01.Text;
            eData.sLineToken02 = tbLineToken02.Text;
            eData.sLineToken03 = tbLineToken03.Text;
            eData.sLineToken04 = tbLineToken04.Text;
            eData.sLineToken05 = tbLineToken05.Text;
            eData.sTelegramId01 = tbTeleId01.Text;
            eData.sTelegramId02 = tbTeleId02.Text;
            eData.sTelegramId03 = tbTeleId03.Text;
            eData.sTelegramId04 = tbTeleId04.Text;
            eData.sTelegramId05 = tbTeleId05.Text;
            eData.sTelegramToken01 = tbTeleToken01.Text;
            eData.sTelegramToken02 = tbTeleToken02.Text;
            eData.sTelegramToken03 = tbTeleToken03.Text;
            eData.sTelegramToken04 = tbTeleToken04.Text;
            eData.sTelegramToken05 = tbTeleToken05.Text;

            JsonSerialize.SaveEnvDataJson(eData, sSite);

            MessageBox.Show("It has been saved!");
        }


    }
}
