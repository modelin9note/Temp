﻿namespace BleDmmMonitor
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnSaveCsv;
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lblSite = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.lblMqttState = new System.Windows.Forms.Label();
            this.lblValue = new System.Windows.Forms.Label();
            this.lblMode = new System.Windows.Forms.Label();
            this.lblDateTimeNow = new System.Windows.Forms.Label();
            this.lblUnit = new System.Windows.Forms.Label();
            this.aGauge1 = new System.Windows.Forms.AGauge();
            this.lvData = new System.Windows.Forms.ListView();
            this.Time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Value = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Unit = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Rsponse = new System.Windows.Forms.TabPage();
            this.btnAcknowledgeAlarm = new System.Windows.Forms.Button();
            this.cbPt100 = new System.Windows.Forms.CheckBox();
            this.cbBleName = new System.Windows.Forms.ComboBox();
            this.nudAutoSave = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNormalMaxValue = new System.Windows.Forms.TextBox();
            this.tbNormalMinValue = new System.Windows.Forms.TextBox();
            this.chTrend = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.nudCycleTime = new System.Windows.Forms.NumericUpDown();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnStopMeasure = new System.Windows.Forms.Button();
            this.btnStopScan = new System.Windows.Forms.Button();
            this.ckbAutoSave = new System.Windows.Forms.CheckBox();
            this.ckbOnMqttPub = new System.Windows.Forms.CheckBox();
            this.ckbAlarmTeleSms = new System.Windows.Forms.CheckBox();
            this.ckbAlarmLineSms = new System.Windows.Forms.CheckBox();
            this.btnMeasement = new System.Windows.Forms.Button();
            this.btnScan = new System.Windows.Forms.Button();
            this.cbScanedDevice = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Settings = new System.Windows.Forms.TabPage();
            this.nudAutoSendSms = new System.Windows.Forms.NumericUpDown();
            this.cbAutoSmsCheck = new System.Windows.Forms.CheckBox();
            this.tbPwdLeft = new System.Windows.Forms.TextBox();
            this.btnSaveSettings = new System.Windows.Forms.Button();
            this.tbTeleToken = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbTeleId = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbPt100OffSet = new System.Windows.Forms.TextBox();
            this.tbMqttPubSuffix = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.rtbResponse = new System.Windows.Forms.RichTextBox();
            this.btnLineNotify = new System.Windows.Forms.Button();
            this.tbNotifyMsg = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbPwdRight = new System.Windows.Forms.TextBox();
            this.tbCharateristicsCode = new System.Windows.Forms.TextBox();
            this.tbMqttPubTopic02 = new System.Windows.Forms.TextBox();
            this.tbMqttPubTopic01 = new System.Windows.Forms.TextBox();
            this.tbMqttSubTopic02 = new System.Windows.Forms.TextBox();
            this.tbMqttSubTopic01 = new System.Windows.Forms.TextBox();
            this.tbPt100Cf = new System.Windows.Forms.TextBox();
            this.tbMqttPubPrefix = new System.Windows.Forms.TextBox();
            this.tbId = new System.Windows.Forms.TextBox();
            this.tbMqttServer = new System.Windows.Forms.TextBox();
            this.tbLineToken = new System.Windows.Forms.TextBox();
            this.tbLineApi = new System.Windows.Forms.TextBox();
            this.tbServiceCode = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Members = new System.Windows.Forms.TabPage();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbTeleToken05 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.tbTeleId05 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.tbTeleToken04 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tbTeleId04 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tbTeleToken03 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tbTeleId03 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tbTeleToken02 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tbTeleId02 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbTeleToken01 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tbTeleId01 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbLineToken05 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tbLineToken04 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbLineToken03 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbLineToken02 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbLineToken01 = new System.Windows.Forms.TextBox();
            this.tbLineApi01 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            btnSaveCsv = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Rsponse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAutoSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chTrend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCycleTime)).BeginInit();
            this.Settings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAutoSendSms)).BeginInit();
            this.Members.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSaveCsv
            // 
            btnSaveCsv.Location = new System.Drawing.Point(789, 104);
            btnSaveCsv.Name = "btnSaveCsv";
            btnSaveCsv.Size = new System.Drawing.Size(195, 47);
            btnSaveCsv.TabIndex = 16;
            btnSaveCsv.Text = "Save Csv";
            btnSaveCsv.UseVisualStyleBackColor = true;
            btnSaveCsv.Click += new System.EventHandler(this.btnSaveCsv_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblSite);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox2);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1390, 807);
            this.splitContainer1.SplitterDistance = 63;
            this.splitContainer1.TabIndex = 0;
            // 
            // lblSite
            // 
            this.lblSite.AutoSize = true;
            this.lblSite.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lblSite.Font = new System.Drawing.Font("Malgun Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblSite.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblSite.Location = new System.Drawing.Point(1287, 1);
            this.lblSite.Name = "lblSite";
            this.lblSite.Size = new System.Drawing.Size(103, 60);
            this.lblSite.TabIndex = 17;
            this.lblSite.Text = "Site";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::BleDmmMonitor.Properties.Resources.TheSeaLab001;
            this.pictureBox2.Location = new System.Drawing.Point(3, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 61);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BleDmmMonitor.Properties.Resources.beautiful_photo_sea_sky;
            this.pictureBox1.Location = new System.Drawing.Point(58, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1332, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer2.Size = new System.Drawing.Size(1390, 740);
            this.splitContainer2.SplitterDistance = 388;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.lblMqttState);
            this.splitContainer3.Panel1.Controls.Add(this.lblValue);
            this.splitContainer3.Panel1.Controls.Add(this.lblMode);
            this.splitContainer3.Panel1.Controls.Add(this.lblDateTimeNow);
            this.splitContainer3.Panel1.Controls.Add(this.lblUnit);
            this.splitContainer3.Panel1.Controls.Add(this.aGauge1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.button1);
            this.splitContainer3.Panel2.Controls.Add(this.lvData);
            this.splitContainer3.Panel2.Controls.Add(this.tbServiceCode);
            this.splitContainer3.Panel2.Controls.Add(this.tbCharateristicsCode);
            this.splitContainer3.Size = new System.Drawing.Size(388, 740);
            this.splitContainer3.SplitterDistance = 290;
            this.splitContainer3.TabIndex = 0;
            // 
            // lblMqttState
            // 
            this.lblMqttState.AutoSize = true;
            this.lblMqttState.Font = new System.Drawing.Font("Malgun Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMqttState.Location = new System.Drawing.Point(3, 258);
            this.lblMqttState.Name = "lblMqttState";
            this.lblMqttState.Size = new System.Drawing.Size(132, 25);
            this.lblMqttState.TabIndex = 21;
            this.lblMqttState.Text = "MQTT State :  ";
            // 
            // lblValue
            // 
            this.lblValue.AutoSize = true;
            this.lblValue.Font = new System.Drawing.Font("Malgun Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblValue.Location = new System.Drawing.Point(12, 113);
            this.lblValue.Name = "lblValue";
            this.lblValue.Size = new System.Drawing.Size(227, 96);
            this.lblValue.TabIndex = 1;
            this.lblValue.Text = "999.9";
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMode.Location = new System.Drawing.Point(257, 30);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(94, 38);
            this.lblMode.TabIndex = 0;
            this.lblMode.Text = "Mode";
            // 
            // lblDateTimeNow
            // 
            this.lblDateTimeNow.AutoSize = true;
            this.lblDateTimeNow.Location = new System.Drawing.Point(9, 12);
            this.lblDateTimeNow.Name = "lblDateTimeNow";
            this.lblDateTimeNow.Size = new System.Drawing.Size(125, 32);
            this.lblDateTimeNow.TabIndex = 1;
            this.lblDateTimeNow.Text = "Date Time";
            // 
            // lblUnit
            // 
            this.lblUnit.AutoSize = true;
            this.lblUnit.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblUnit.Location = new System.Drawing.Point(61, 193);
            this.lblUnit.Name = "lblUnit";
            this.lblUnit.Size = new System.Drawing.Size(73, 38);
            this.lblUnit.TabIndex = 2;
            this.lblUnit.Text = "Unit";
            // 
            // aGauge1
            // 
            this.aGauge1.BaseArcColor = System.Drawing.Color.Black;
            this.aGauge1.BaseArcRadius = 80;
            this.aGauge1.BaseArcStart = 135;
            this.aGauge1.BaseArcSweep = 270;
            this.aGauge1.BaseArcWidth = 2;
            this.aGauge1.Center = new System.Drawing.Point(120, 120);
            this.aGauge1.Font = new System.Drawing.Font("Malgun Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aGauge1.Location = new System.Drawing.Point(160, 77);
            this.aGauge1.MaxValue = 600F;
            this.aGauge1.MinValue = 0F;
            this.aGauge1.Name = "aGauge1";
            this.aGauge1.NeedleColor1 = System.Windows.Forms.AGaugeNeedleColor.Gray;
            this.aGauge1.NeedleColor2 = System.Drawing.Color.Red;
            this.aGauge1.NeedleRadius = 85;
            this.aGauge1.NeedleType = System.Windows.Forms.NeedleType.Advance;
            this.aGauge1.NeedleWidth = 2;
            this.aGauge1.ScaleLinesInterColor = System.Drawing.Color.Red;
            this.aGauge1.ScaleLinesInterInnerRadius = 73;
            this.aGauge1.ScaleLinesInterOuterRadius = 80;
            this.aGauge1.ScaleLinesInterWidth = 1;
            this.aGauge1.ScaleLinesMajorColor = System.Drawing.Color.Red;
            this.aGauge1.ScaleLinesMajorInnerRadius = 70;
            this.aGauge1.ScaleLinesMajorOuterRadius = 80;
            this.aGauge1.ScaleLinesMajorStepValue = 40F;
            this.aGauge1.ScaleLinesMajorWidth = 2;
            this.aGauge1.ScaleLinesMinorColor = System.Drawing.Color.Maroon;
            this.aGauge1.ScaleLinesMinorInnerRadius = 75;
            this.aGauge1.ScaleLinesMinorOuterRadius = 80;
            this.aGauge1.ScaleLinesMinorTicks = 9;
            this.aGauge1.ScaleLinesMinorWidth = 1;
            this.aGauge1.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge1.ScaleNumbersFormat = null;
            this.aGauge1.ScaleNumbersRadius = 95;
            this.aGauge1.ScaleNumbersRotation = 0;
            this.aGauge1.ScaleNumbersStartScaleLine = 0;
            this.aGauge1.ScaleNumbersStepScaleLines = 1;
            this.aGauge1.Size = new System.Drawing.Size(230, 206);
            this.aGauge1.TabIndex = 0;
            this.aGauge1.Value = 0F;
            // 
            // lvData
            // 
            this.lvData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Time,
            this.Value,
            this.Unit});
            this.lvData.HideSelection = false;
            this.lvData.Location = new System.Drawing.Point(0, 0);
            this.lvData.Name = "lvData";
            this.lvData.Size = new System.Drawing.Size(80, 446);
            this.lvData.Sorting = System.Windows.Forms.SortOrder.Descending;
            this.lvData.TabIndex = 4;
            this.lvData.UseCompatibleStateImageBehavior = false;
            this.lvData.View = System.Windows.Forms.View.Details;
            // 
            // Time
            // 
            this.Time.Text = "Time";
            this.Time.Width = 205;
            // 
            // Value
            // 
            this.Value.Text = "Value";
            this.Value.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Value.Width = 123;
            // 
            // Unit
            // 
            this.Unit.Text = "Unit";
            this.Unit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Unit.Width = 55;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Rsponse);
            this.tabControl1.Controls.Add(this.Settings);
            this.tabControl1.Controls.Add(this.Members);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(998, 740);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // Rsponse
            // 
            this.Rsponse.Controls.Add(this.richTextBox1);
            this.Rsponse.Controls.Add(this.btnAcknowledgeAlarm);
            this.Rsponse.Controls.Add(this.cbPt100);
            this.Rsponse.Controls.Add(this.cbBleName);
            this.Rsponse.Controls.Add(this.nudAutoSave);
            this.Rsponse.Controls.Add(btnSaveCsv);
            this.Rsponse.Controls.Add(this.label3);
            this.Rsponse.Controls.Add(this.tbNormalMaxValue);
            this.Rsponse.Controls.Add(this.tbNormalMinValue);
            this.Rsponse.Controls.Add(this.chTrend);
            this.Rsponse.Controls.Add(this.nudCycleTime);
            this.Rsponse.Controls.Add(this.btnConnect);
            this.Rsponse.Controls.Add(this.btnStopMeasure);
            this.Rsponse.Controls.Add(this.btnStopScan);
            this.Rsponse.Controls.Add(this.ckbAutoSave);
            this.Rsponse.Controls.Add(this.ckbOnMqttPub);
            this.Rsponse.Controls.Add(this.ckbAlarmTeleSms);
            this.Rsponse.Controls.Add(this.ckbAlarmLineSms);
            this.Rsponse.Controls.Add(this.btnMeasement);
            this.Rsponse.Controls.Add(this.btnScan);
            this.Rsponse.Controls.Add(this.cbScanedDevice);
            this.Rsponse.Controls.Add(this.label2);
            this.Rsponse.Controls.Add(this.label1);
            this.Rsponse.Controls.Add(this.label4);
            this.Rsponse.Location = new System.Drawing.Point(4, 41);
            this.Rsponse.Name = "Rsponse";
            this.Rsponse.Padding = new System.Windows.Forms.Padding(3);
            this.Rsponse.Size = new System.Drawing.Size(990, 695);
            this.Rsponse.TabIndex = 0;
            this.Rsponse.Text = "Main";
            this.Rsponse.UseVisualStyleBackColor = true;
            this.Rsponse.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // btnAcknowledgeAlarm
            // 
            this.btnAcknowledgeAlarm.Location = new System.Drawing.Point(608, 217);
            this.btnAcknowledgeAlarm.Name = "btnAcknowledgeAlarm";
            this.btnAcknowledgeAlarm.Size = new System.Drawing.Size(169, 50);
            this.btnAcknowledgeAlarm.TabIndex = 20;
            this.btnAcknowledgeAlarm.Text = "ACK Alarm";
            this.btnAcknowledgeAlarm.UseVisualStyleBackColor = true;
            this.btnAcknowledgeAlarm.Click += new System.EventHandler(this.btnAcknowledgeAlarm_Click);
            // 
            // cbPt100
            // 
            this.cbPt100.AutoSize = true;
            this.cbPt100.Location = new System.Drawing.Point(458, 172);
            this.cbPt100.Name = "cbPt100";
            this.cbPt100.Size = new System.Drawing.Size(116, 36);
            this.cbPt100.TabIndex = 19;
            this.cbPt100.Text = "PT-100";
            this.cbPt100.UseVisualStyleBackColor = true;
            // 
            // cbBleName
            // 
            this.cbBleName.FormattingEnabled = true;
            this.cbBleName.Items.AddRange(new object[] {
            "tps",
            "All"});
            this.cbBleName.Location = new System.Drawing.Point(162, 57);
            this.cbBleName.Name = "cbBleName";
            this.cbBleName.Size = new System.Drawing.Size(98, 40);
            this.cbBleName.TabIndex = 18;
            // 
            // nudAutoSave
            // 
            this.nudAutoSave.Location = new System.Drawing.Point(901, 169);
            this.nudAutoSave.Maximum = new decimal(new int[] {
            864000,
            0,
            0,
            0});
            this.nudAutoSave.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.nudAutoSave.Name = "nudAutoSave";
            this.nudAutoSave.Size = new System.Drawing.Size(83, 39);
            this.nudAutoSave.TabIndex = 17;
            this.nudAutoSave.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudAutoSave.Value = new decimal(new int[] {
            86400,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(574, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 32);
            this.label3.TabIndex = 15;
            this.label3.Text = "~";
            // 
            // tbNormalMaxValue
            // 
            this.tbNormalMaxValue.Location = new System.Drawing.Point(608, 108);
            this.tbNormalMaxValue.Name = "tbNormalMaxValue";
            this.tbNormalMaxValue.Size = new System.Drawing.Size(169, 39);
            this.tbNormalMaxValue.TabIndex = 14;
            this.tbNormalMaxValue.Text = "333";
            this.tbNormalMaxValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbNormalMinValue
            // 
            this.tbNormalMinValue.Location = new System.Drawing.Point(445, 107);
            this.tbNormalMinValue.Name = "tbNormalMinValue";
            this.tbNormalMinValue.Size = new System.Drawing.Size(129, 39);
            this.tbNormalMinValue.TabIndex = 14;
            this.tbNormalMinValue.Text = "0.00";
            this.tbNormalMinValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chTrend
            // 
            chartArea1.Name = "ChartArea1";
            this.chTrend.ChartAreas.Add(chartArea1);
            this.chTrend.Location = new System.Drawing.Point(12, 271);
            this.chTrend.Name = "chTrend";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Diamond;
            series1.Name = "Series1";
            this.chTrend.Series.Add(series1);
            this.chTrend.Size = new System.Drawing.Size(968, 418);
            this.chTrend.TabIndex = 13;
            this.chTrend.Text = "chart1";
            this.chTrend.Click += new System.EventHandler(this.chTrend_Click);
            // 
            // nudCycleTime
            // 
            this.nudCycleTime.Location = new System.Drawing.Point(162, 106);
            this.nudCycleTime.Maximum = new decimal(new int[] {
            86400,
            0,
            0,
            0});
            this.nudCycleTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCycleTime.Name = "nudCycleTime";
            this.nudCycleTime.Size = new System.Drawing.Size(98, 39);
            this.nudCycleTime.TabIndex = 11;
            this.nudCycleTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCycleTime.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(789, 58);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(195, 40);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnStopMeasure
            // 
            this.btnStopMeasure.Location = new System.Drawing.Point(789, 217);
            this.btnStopMeasure.Name = "btnStopMeasure";
            this.btnStopMeasure.Size = new System.Drawing.Size(195, 50);
            this.btnStopMeasure.TabIndex = 6;
            this.btnStopMeasure.Text = "Halt";
            this.btnStopMeasure.UseVisualStyleBackColor = true;
            this.btnStopMeasure.Click += new System.EventHandler(this.btnStopMeasure_Click);
            // 
            // btnStopScan
            // 
            this.btnStopScan.Location = new System.Drawing.Point(789, 14);
            this.btnStopScan.Name = "btnStopScan";
            this.btnStopScan.Size = new System.Drawing.Size(195, 38);
            this.btnStopScan.TabIndex = 2;
            this.btnStopScan.Text = "Stop";
            this.btnStopScan.UseVisualStyleBackColor = true;
            this.btnStopScan.Click += new System.EventHandler(this.btnStopScan_Click);
            // 
            // ckbAutoSave
            // 
            this.ckbAutoSave.AutoSize = true;
            this.ckbAutoSave.Location = new System.Drawing.Point(772, 170);
            this.ckbAutoSave.Name = "ckbAutoSave";
            this.ckbAutoSave.Size = new System.Drawing.Size(190, 36);
            this.ckbAutoSave.TabIndex = 2;
            this.ckbAutoSave.Text = "AutoSave(sec)";
            this.ckbAutoSave.UseVisualStyleBackColor = true;
            this.ckbAutoSave.CheckedChanged += new System.EventHandler(this.ckbAutoSave_CheckedChanged);
            // 
            // ckbOnMqttPub
            // 
            this.ckbOnMqttPub.AutoSize = true;
            this.ckbOnMqttPub.Checked = true;
            this.ckbOnMqttPub.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbOnMqttPub.Location = new System.Drawing.Point(351, 172);
            this.ckbOnMqttPub.Name = "ckbOnMqttPub";
            this.ckbOnMqttPub.Size = new System.Drawing.Size(148, 36);
            this.ckbOnMqttPub.TabIndex = 2;
            this.ckbOnMqttPub.Text = "On MQTT";
            this.ckbOnMqttPub.UseVisualStyleBackColor = true;
            // 
            // ckbAlarmTeleSms
            // 
            this.ckbAlarmTeleSms.AutoSize = true;
            this.ckbAlarmTeleSms.Location = new System.Drawing.Point(162, 172);
            this.ckbAlarmTeleSms.Name = "ckbAlarmTeleSms";
            this.ckbAlarmTeleSms.Size = new System.Drawing.Size(263, 36);
            this.ckbAlarmTeleSms.TabIndex = 2;
            this.ckbAlarmTeleSms.Text = "Alarm Telegram Sms";
            this.ckbAlarmTeleSms.UseVisualStyleBackColor = true;
            // 
            // ckbAlarmLineSms
            // 
            this.ckbAlarmLineSms.AutoSize = true;
            this.ckbAlarmLineSms.Checked = true;
            this.ckbAlarmLineSms.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbAlarmLineSms.Location = new System.Drawing.Point(12, 172);
            this.ckbAlarmLineSms.Name = "ckbAlarmLineSms";
            this.ckbAlarmLineSms.Size = new System.Drawing.Size(208, 36);
            this.ckbAlarmLineSms.TabIndex = 2;
            this.ckbAlarmLineSms.Text = "Alarm Line Sms";
            this.ckbAlarmLineSms.UseVisualStyleBackColor = true;
            // 
            // btnMeasement
            // 
            this.btnMeasement.Location = new System.Drawing.Point(12, 217);
            this.btnMeasement.Name = "btnMeasement";
            this.btnMeasement.Size = new System.Drawing.Size(593, 50);
            this.btnMeasement.TabIndex = 5;
            this.btnMeasement.Text = "Measurement";
            this.btnMeasement.UseVisualStyleBackColor = true;
            this.btnMeasement.Click += new System.EventHandler(this.btnMeasement_Click);
            // 
            // btnScan
            // 
            this.btnScan.Location = new System.Drawing.Point(12, 14);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(765, 38);
            this.btnScan.TabIndex = 1;
            this.btnScan.Text = "Scan Ble DMM";
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // cbScanedDevice
            // 
            this.cbScanedDevice.FormattingEnabled = true;
            this.cbScanedDevice.Location = new System.Drawing.Point(266, 58);
            this.cbScanedDevice.Name = "cbScanedDevice";
            this.cbScanedDevice.Size = new System.Drawing.Size(511, 40);
            this.cbScanedDevice.TabIndex = 3;
            this.cbScanedDevice.SelectedIndexChanged += new System.EventHandler(this.cbScanedDevice_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(266, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Normal Range : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cycle Time(sec) : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 32);
            this.label4.TabIndex = 1;
            this.label4.Text = "Ble Device Select :";
            // 
            // Settings
            // 
            this.Settings.AutoScroll = true;
            this.Settings.Controls.Add(this.nudAutoSendSms);
            this.Settings.Controls.Add(this.cbAutoSmsCheck);
            this.Settings.Controls.Add(this.tbPwdLeft);
            this.Settings.Controls.Add(this.btnSaveSettings);
            this.Settings.Controls.Add(this.tbTeleToken);
            this.Settings.Controls.Add(this.label18);
            this.Settings.Controls.Add(this.tbTeleId);
            this.Settings.Controls.Add(this.label17);
            this.Settings.Controls.Add(this.tbPt100OffSet);
            this.Settings.Controls.Add(this.tbMqttPubSuffix);
            this.Settings.Controls.Add(this.label37);
            this.Settings.Controls.Add(this.label16);
            this.Settings.Controls.Add(this.rtbResponse);
            this.Settings.Controls.Add(this.btnLineNotify);
            this.Settings.Controls.Add(this.tbNotifyMsg);
            this.Settings.Controls.Add(this.label7);
            this.Settings.Controls.Add(this.tbPwdRight);
            this.Settings.Controls.Add(this.tbMqttPubTopic02);
            this.Settings.Controls.Add(this.tbMqttPubTopic01);
            this.Settings.Controls.Add(this.tbMqttSubTopic02);
            this.Settings.Controls.Add(this.tbMqttSubTopic01);
            this.Settings.Controls.Add(this.tbPt100Cf);
            this.Settings.Controls.Add(this.tbMqttPubPrefix);
            this.Settings.Controls.Add(this.tbId);
            this.Settings.Controls.Add(this.tbMqttServer);
            this.Settings.Controls.Add(this.tbLineToken);
            this.Settings.Controls.Add(this.tbLineApi);
            this.Settings.Controls.Add(this.label10);
            this.Settings.Controls.Add(this.label11);
            this.Settings.Controls.Add(this.label14);
            this.Settings.Controls.Add(this.label36);
            this.Settings.Controls.Add(this.label15);
            this.Settings.Controls.Add(this.label13);
            this.Settings.Controls.Add(this.label8);
            this.Settings.Controls.Add(this.label12);
            this.Settings.Controls.Add(this.label9);
            this.Settings.Controls.Add(this.label6);
            this.Settings.Controls.Add(this.label5);
            this.Settings.Location = new System.Drawing.Point(4, 41);
            this.Settings.Name = "Settings";
            this.Settings.Padding = new System.Windows.Forms.Padding(3);
            this.Settings.Size = new System.Drawing.Size(990, 695);
            this.Settings.TabIndex = 1;
            this.Settings.Text = "Setting";
            this.Settings.UseVisualStyleBackColor = true;
            // 
            // nudAutoSendSms
            // 
            this.nudAutoSendSms.Location = new System.Drawing.Point(770, 424);
            this.nudAutoSendSms.Maximum = new decimal(new int[] {
            864000,
            0,
            0,
            0});
            this.nudAutoSendSms.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudAutoSendSms.Name = "nudAutoSendSms";
            this.nudAutoSendSms.Size = new System.Drawing.Size(212, 39);
            this.nudAutoSendSms.TabIndex = 23;
            this.nudAutoSendSms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudAutoSendSms.Value = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            // 
            // cbAutoSmsCheck
            // 
            this.cbAutoSmsCheck.AutoSize = true;
            this.cbAutoSmsCheck.Checked = true;
            this.cbAutoSmsCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAutoSmsCheck.Location = new System.Drawing.Point(513, 424);
            this.cbAutoSmsCheck.Name = "cbAutoSmsCheck";
            this.cbAutoSmsCheck.Size = new System.Drawing.Size(251, 36);
            this.cbAutoSmsCheck.TabIndex = 22;
            this.cbAutoSmsCheck.Text = "AutoSendSms(sec) :";
            this.cbAutoSmsCheck.UseVisualStyleBackColor = true;
            // 
            // tbPwdLeft
            // 
            this.tbPwdLeft.Location = new System.Drawing.Point(571, 478);
            this.tbPwdLeft.Name = "tbPwdLeft";
            this.tbPwdLeft.PasswordChar = '*';
            this.tbPwdLeft.Size = new System.Drawing.Size(202, 39);
            this.tbPwdLeft.TabIndex = 21;
            this.tbPwdLeft.Text = "sea1188";
            this.tbPwdLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnSaveSettings
            // 
            this.btnSaveSettings.Location = new System.Drawing.Point(11, 637);
            this.btnSaveSettings.Name = "btnSaveSettings";
            this.btnSaveSettings.Size = new System.Drawing.Size(973, 62);
            this.btnSaveSettings.TabIndex = 20;
            this.btnSaveSettings.Text = "Save the Settings";
            this.btnSaveSettings.UseVisualStyleBackColor = true;
            this.btnSaveSettings.Click += new System.EventHandler(this.btnSaveSettings_Click);
            // 
            // tbTeleToken
            // 
            this.tbTeleToken.Location = new System.Drawing.Point(161, 192);
            this.tbTeleToken.Name = "tbTeleToken";
            this.tbTeleToken.Size = new System.Drawing.Size(821, 39);
            this.tbTeleToken.TabIndex = 19;
            this.tbTeleToken.Text = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
            this.tbTeleToken.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 195);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(201, 32);
            this.label18.TabIndex = 18;
            this.label18.Text = "Telegram Token :";
            // 
            // tbTeleId
            // 
            this.tbTeleId.Location = new System.Drawing.Point(161, 157);
            this.tbTeleId.Name = "tbTeleId";
            this.tbTeleId.Size = new System.Drawing.Size(821, 39);
            this.tbTeleId.TabIndex = 17;
            this.tbTeleId.Text = "6781069006";
            this.tbTeleId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 160);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(155, 32);
            this.label17.TabIndex = 16;
            this.label17.Text = "Telegram Id :";
            // 
            // tbPt100OffSet
            // 
            this.tbPt100OffSet.Location = new System.Drawing.Point(654, 385);
            this.tbPt100OffSet.Name = "tbPt100OffSet";
            this.tbPt100OffSet.Size = new System.Drawing.Size(328, 39);
            this.tbPt100OffSet.TabIndex = 15;
            this.tbPt100OffSet.Text = "0.100";
            this.tbPt100OffSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttPubSuffix
            // 
            this.tbMqttPubSuffix.Location = new System.Drawing.Point(654, 346);
            this.tbMqttPubSuffix.Name = "tbMqttPubSuffix";
            this.tbMqttPubSuffix.Size = new System.Drawing.Size(328, 39);
            this.tbMqttPubSuffix.TabIndex = 15;
            this.tbMqttPubSuffix.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(507, 388);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(192, 32);
            this.label37.TabIndex = 14;
            this.label37.Text = "PT-100 OFFSET :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(507, 349);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(162, 32);
            this.label16.TabIndex = 14;
            this.label16.Text = "MQTT Suffix :";
            // 
            // rtbResponse
            // 
            this.rtbResponse.Location = new System.Drawing.Point(506, 544);
            this.rtbResponse.Name = "rtbResponse";
            this.rtbResponse.Size = new System.Drawing.Size(481, 23);
            this.rtbResponse.TabIndex = 13;
            this.rtbResponse.Text = "";
            this.rtbResponse.Visible = false;
            // 
            // btnLineNotify
            // 
            this.btnLineNotify.Location = new System.Drawing.Point(782, 558);
            this.btnLineNotify.Name = "btnLineNotify";
            this.btnLineNotify.Size = new System.Drawing.Size(202, 75);
            this.btnLineNotify.TabIndex = 11;
            this.btnLineNotify.Text = "Line Notify";
            this.btnLineNotify.UseVisualStyleBackColor = true;
            this.btnLineNotify.Click += new System.EventHandler(this.btnLineNotify_Click);
            // 
            // tbNotifyMsg
            // 
            this.tbNotifyMsg.Location = new System.Drawing.Point(11, 558);
            this.tbNotifyMsg.Multiline = true;
            this.tbNotifyMsg.Name = "tbNotifyMsg";
            this.tbNotifyMsg.Size = new System.Drawing.Size(762, 75);
            this.tbNotifyMsg.TabIndex = 10;
            this.tbNotifyMsg.Text = "Test Sms Alarm on Line and Telegram~ ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 523);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(192, 32);
            this.label7.TabIndex = 9;
            this.label7.Text = "Notify Messages";
            // 
            // tbPwdRight
            // 
            this.tbPwdRight.Location = new System.Drawing.Point(782, 478);
            this.tbPwdRight.Name = "tbPwdRight";
            this.tbPwdRight.PasswordChar = '*';
            this.tbPwdRight.Size = new System.Drawing.Size(202, 39);
            this.tbPwdRight.TabIndex = 7;
            this.tbPwdRight.Text = "sea1188";
            this.tbPwdRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCharateristicsCode
            // 
            this.tbCharateristicsCode.Location = new System.Drawing.Point(150, 77);
            this.tbCharateristicsCode.Name = "tbCharateristicsCode";
            this.tbCharateristicsCode.Size = new System.Drawing.Size(235, 39);
            this.tbCharateristicsCode.TabIndex = 7;
            this.tbCharateristicsCode.Text = "FFF4";
            this.tbCharateristicsCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttPubTopic02
            // 
            this.tbMqttPubTopic02.Location = new System.Drawing.Point(584, 311);
            this.tbMqttPubTopic02.Name = "tbMqttPubTopic02";
            this.tbMqttPubTopic02.Size = new System.Drawing.Size(398, 39);
            this.tbMqttPubTopic02.TabIndex = 8;
            this.tbMqttPubTopic02.Text = "MqttPub/Monitor/Device001b";
            this.tbMqttPubTopic02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttPubTopic01
            // 
            this.tbMqttPubTopic01.Location = new System.Drawing.Point(161, 311);
            this.tbMqttPubTopic01.Name = "tbMqttPubTopic01";
            this.tbMqttPubTopic01.Size = new System.Drawing.Size(398, 39);
            this.tbMqttPubTopic01.TabIndex = 8;
            this.tbMqttPubTopic01.Text = "MqttPub/Monitor/Device001a";
            this.tbMqttPubTopic01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttSubTopic02
            // 
            this.tbMqttSubTopic02.Location = new System.Drawing.Point(584, 276);
            this.tbMqttSubTopic02.Name = "tbMqttSubTopic02";
            this.tbMqttSubTopic02.Size = new System.Drawing.Size(398, 39);
            this.tbMqttSubTopic02.TabIndex = 8;
            this.tbMqttSubTopic02.Text = "MqttSub/Monitor/Device001b";
            this.tbMqttSubTopic02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttSubTopic01
            // 
            this.tbMqttSubTopic01.Location = new System.Drawing.Point(161, 276);
            this.tbMqttSubTopic01.Name = "tbMqttSubTopic01";
            this.tbMqttSubTopic01.Size = new System.Drawing.Size(398, 39);
            this.tbMqttSubTopic01.TabIndex = 8;
            this.tbMqttSubTopic01.Text = "MqttSub/Monitor/Device001a";
            this.tbMqttSubTopic01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbPt100Cf
            // 
            this.tbPt100Cf.Location = new System.Drawing.Point(161, 385);
            this.tbPt100Cf.Name = "tbPt100Cf";
            this.tbPt100Cf.Size = new System.Drawing.Size(326, 39);
            this.tbPt100Cf.TabIndex = 8;
            this.tbPt100Cf.Text = "0.00039083";
            this.tbPt100Cf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttPubPrefix
            // 
            this.tbMqttPubPrefix.Location = new System.Drawing.Point(161, 346);
            this.tbMqttPubPrefix.Name = "tbMqttPubPrefix";
            this.tbMqttPubPrefix.Size = new System.Drawing.Size(326, 39);
            this.tbMqttPubPrefix.TabIndex = 8;
            this.tbMqttPubPrefix.Text = "Measure :  ";
            this.tbMqttPubPrefix.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbId
            // 
            this.tbId.Location = new System.Drawing.Point(161, 478);
            this.tbId.Name = "tbId";
            this.tbId.Size = new System.Drawing.Size(289, 39);
            this.tbId.TabIndex = 8;
            this.tbId.Text = "sealab";
            this.tbId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMqttServer
            // 
            this.tbMqttServer.Location = new System.Drawing.Point(161, 241);
            this.tbMqttServer.Name = "tbMqttServer";
            this.tbMqttServer.Size = new System.Drawing.Size(821, 39);
            this.tbMqttServer.TabIndex = 8;
            this.tbMqttServer.Text = "broker.emqx.io";
            this.tbMqttServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbLineToken
            // 
            this.tbLineToken.Location = new System.Drawing.Point(161, 109);
            this.tbLineToken.Name = "tbLineToken";
            this.tbLineToken.Size = new System.Drawing.Size(821, 39);
            this.tbLineToken.TabIndex = 8;
            this.tbLineToken.Text = "mqUOh7TpI4zdGYpYazGAtgTimDWsdsz9xW5aFssOOKg";
            this.tbLineToken.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbLineApi
            // 
            this.tbLineApi.Location = new System.Drawing.Point(161, 74);
            this.tbLineApi.Name = "tbLineApi";
            this.tbLineApi.Size = new System.Drawing.Size(821, 39);
            this.tbLineApi.TabIndex = 8;
            this.tbLineApi.Text = "https://notify-api.line.me/api/notify";
            this.tbLineApi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbServiceCode
            // 
            this.tbServiceCode.Location = new System.Drawing.Point(150, 23);
            this.tbServiceCode.Name = "tbServiceCode";
            this.tbServiceCode.Size = new System.Drawing.Size(236, 39);
            this.tbServiceCode.TabIndex = 8;
            this.tbServiceCode.Text = "FFF0";
            this.tbServiceCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 311);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 32);
            this.label10.TabIndex = 5;
            this.label10.Text = "Publish Topic :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 279);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(196, 32);
            this.label11.TabIndex = 5;
            this.label11.Text = "Subscribe Topic :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 244);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(169, 32);
            this.label14.TabIndex = 5;
            this.label14.Text = "MQTT Server :";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 388);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(205, 32);
            this.label36.TabIndex = 5;
            this.label36.Text = "PT-100 CF(Ω/°C) :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 349);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(162, 32);
            this.label15.TabIndex = 5;
            this.label15.Text = "MQTT Prefix :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(103, 481);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 32);
            this.label13.TabIndex = 5;
            this.label13.Text = "ID :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 32);
            this.label8.TabIndex = 5;
            this.label8.Text = "Line Token :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(470, 481);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 32);
            this.label12.TabIndex = 6;
            this.label12.Text = "Password :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 32);
            this.label9.TabIndex = 5;
            this.label9.Text = "Line API :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(167, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "Service Code :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(460, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 32);
            this.label5.TabIndex = 6;
            this.label5.Text = "Charateristics :";
            // 
            // Members
            // 
            this.Members.AutoScroll = true;
            this.Members.Controls.Add(this.label35);
            this.Members.Controls.Add(this.groupBox2);
            this.Members.Controls.Add(this.groupBox1);
            this.Members.Location = new System.Drawing.Point(4, 28);
            this.Members.Name = "Members";
            this.Members.Padding = new System.Windows.Forms.Padding(3);
            this.Members.Size = new System.Drawing.Size(990, 708);
            this.Members.TabIndex = 2;
            this.Members.Text = "Members";
            this.Members.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(584, 263);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(388, 32);
            this.label35.TabIndex = 41;
            this.label35.Text = "* It will be applied in five minutes!";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbTeleToken05);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.tbTeleId05);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.tbTeleToken04);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.tbTeleId04);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.tbTeleToken03);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.tbTeleId03);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.tbTeleToken02);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.tbTeleId02);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.tbTeleToken01);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.tbTeleId01);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Location = new System.Drawing.Point(6, 282);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(977, 396);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Telegram Member";
            // 
            // tbTeleToken05
            // 
            this.tbTeleToken05.Location = new System.Drawing.Point(149, 345);
            this.tbTeleToken05.Name = "tbTeleToken05";
            this.tbTeleToken05.Size = new System.Drawing.Size(821, 39);
            this.tbTeleToken05.TabIndex = 40;
            this.tbTeleToken05.Text = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
            this.tbTeleToken05.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(7, 348);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(201, 32);
            this.label33.TabIndex = 39;
            this.label33.Text = "Telegram Token :";
            // 
            // tbTeleId05
            // 
            this.tbTeleId05.Location = new System.Drawing.Point(149, 310);
            this.tbTeleId05.Name = "tbTeleId05";
            this.tbTeleId05.Size = new System.Drawing.Size(821, 39);
            this.tbTeleId05.TabIndex = 38;
            this.tbTeleId05.Text = "6781069006";
            this.tbTeleId05.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(7, 313);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(155, 32);
            this.label34.TabIndex = 37;
            this.label34.Text = "Telegram Id :";
            // 
            // tbTeleToken04
            // 
            this.tbTeleToken04.Location = new System.Drawing.Point(149, 275);
            this.tbTeleToken04.Name = "tbTeleToken04";
            this.tbTeleToken04.Size = new System.Drawing.Size(821, 39);
            this.tbTeleToken04.TabIndex = 36;
            this.tbTeleToken04.Text = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
            this.tbTeleToken04.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(7, 278);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(201, 32);
            this.label31.TabIndex = 35;
            this.label31.Text = "Telegram Token :";
            // 
            // tbTeleId04
            // 
            this.tbTeleId04.Location = new System.Drawing.Point(149, 240);
            this.tbTeleId04.Name = "tbTeleId04";
            this.tbTeleId04.Size = new System.Drawing.Size(821, 39);
            this.tbTeleId04.TabIndex = 34;
            this.tbTeleId04.Text = "6781069006";
            this.tbTeleId04.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(7, 243);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(155, 32);
            this.label32.TabIndex = 33;
            this.label32.Text = "Telegram Id :";
            // 
            // tbTeleToken03
            // 
            this.tbTeleToken03.Location = new System.Drawing.Point(149, 205);
            this.tbTeleToken03.Name = "tbTeleToken03";
            this.tbTeleToken03.Size = new System.Drawing.Size(821, 39);
            this.tbTeleToken03.TabIndex = 32;
            this.tbTeleToken03.Text = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
            this.tbTeleToken03.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(7, 208);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(201, 32);
            this.label29.TabIndex = 31;
            this.label29.Text = "Telegram Token :";
            // 
            // tbTeleId03
            // 
            this.tbTeleId03.Location = new System.Drawing.Point(149, 170);
            this.tbTeleId03.Name = "tbTeleId03";
            this.tbTeleId03.Size = new System.Drawing.Size(821, 39);
            this.tbTeleId03.TabIndex = 30;
            this.tbTeleId03.Text = "6781069006";
            this.tbTeleId03.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(7, 173);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(155, 32);
            this.label30.TabIndex = 29;
            this.label30.Text = "Telegram Id :";
            // 
            // tbTeleToken02
            // 
            this.tbTeleToken02.Location = new System.Drawing.Point(149, 135);
            this.tbTeleToken02.Name = "tbTeleToken02";
            this.tbTeleToken02.Size = new System.Drawing.Size(821, 39);
            this.tbTeleToken02.TabIndex = 28;
            this.tbTeleToken02.Text = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
            this.tbTeleToken02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(7, 138);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(201, 32);
            this.label27.TabIndex = 27;
            this.label27.Text = "Telegram Token :";
            // 
            // tbTeleId02
            // 
            this.tbTeleId02.Location = new System.Drawing.Point(149, 100);
            this.tbTeleId02.Name = "tbTeleId02";
            this.tbTeleId02.Size = new System.Drawing.Size(821, 39);
            this.tbTeleId02.TabIndex = 26;
            this.tbTeleId02.Text = "6781069006";
            this.tbTeleId02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(7, 103);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(155, 32);
            this.label28.TabIndex = 25;
            this.label28.Text = "Telegram Id :";
            // 
            // tbTeleToken01
            // 
            this.tbTeleToken01.Location = new System.Drawing.Point(149, 65);
            this.tbTeleToken01.Name = "tbTeleToken01";
            this.tbTeleToken01.Size = new System.Drawing.Size(821, 39);
            this.tbTeleToken01.TabIndex = 24;
            this.tbTeleToken01.Text = "6777584208:AAHJAks6oiAODDw70OymTAhkntLMHinc6BU";
            this.tbTeleToken01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 68);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(201, 32);
            this.label25.TabIndex = 23;
            this.label25.Text = "Telegram Token :";
            // 
            // tbTeleId01
            // 
            this.tbTeleId01.Location = new System.Drawing.Point(149, 30);
            this.tbTeleId01.Name = "tbTeleId01";
            this.tbTeleId01.Size = new System.Drawing.Size(821, 39);
            this.tbTeleId01.TabIndex = 22;
            this.tbTeleId01.Text = "6781069006";
            this.tbTeleId01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(7, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(155, 32);
            this.label26.TabIndex = 21;
            this.label26.Text = "Telegram Id :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbLineToken05);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.tbLineToken04);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.tbLineToken03);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.tbLineToken02);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.tbLineToken01);
            this.groupBox1.Controls.Add(this.tbLineApi01);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(983, 253);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Naver Line Member";
            // 
            // tbLineToken05
            // 
            this.tbLineToken05.Location = new System.Drawing.Point(151, 212);
            this.tbLineToken05.Name = "tbLineToken05";
            this.tbLineToken05.Size = new System.Drawing.Size(821, 39);
            this.tbLineToken05.TabIndex = 20;
            this.tbLineToken05.Text = "mqUOh7TpI4zdGYpYazGAtgTimDWsdsz9xW5aFssOOKg";
            this.tbLineToken05.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 215);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(146, 32);
            this.label24.TabIndex = 19;
            this.label24.Text = "Line Token :";
            // 
            // tbLineToken04
            // 
            this.tbLineToken04.Location = new System.Drawing.Point(151, 177);
            this.tbLineToken04.Name = "tbLineToken04";
            this.tbLineToken04.Size = new System.Drawing.Size(821, 39);
            this.tbLineToken04.TabIndex = 18;
            this.tbLineToken04.Text = "mqUOh7TpI4zdGYpYazGAtgTimDWsdsz9xW5aFssOOKg";
            this.tbLineToken04.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 180);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(146, 32);
            this.label23.TabIndex = 17;
            this.label23.Text = "Line Token :";
            // 
            // tbLineToken03
            // 
            this.tbLineToken03.Location = new System.Drawing.Point(151, 142);
            this.tbLineToken03.Name = "tbLineToken03";
            this.tbLineToken03.Size = new System.Drawing.Size(821, 39);
            this.tbLineToken03.TabIndex = 16;
            this.tbLineToken03.Text = "mqUOh7TpI4zdGYpYazGAtgTimDWsdsz9xW5aFssOOKg";
            this.tbLineToken03.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 145);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(146, 32);
            this.label22.TabIndex = 15;
            this.label22.Text = "Line Token :";
            // 
            // tbLineToken02
            // 
            this.tbLineToken02.Location = new System.Drawing.Point(151, 107);
            this.tbLineToken02.Name = "tbLineToken02";
            this.tbLineToken02.Size = new System.Drawing.Size(821, 39);
            this.tbLineToken02.TabIndex = 14;
            this.tbLineToken02.Text = "mqUOh7TpI4zdGYpYazGAtgTimDWsdsz9xW5aFssOOKg";
            this.tbLineToken02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(9, 110);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(146, 32);
            this.label21.TabIndex = 13;
            this.label21.Text = "Line Token :";
            // 
            // tbLineToken01
            // 
            this.tbLineToken01.Location = new System.Drawing.Point(151, 72);
            this.tbLineToken01.Name = "tbLineToken01";
            this.tbLineToken01.Size = new System.Drawing.Size(821, 39);
            this.tbLineToken01.TabIndex = 11;
            this.tbLineToken01.Text = "mqUOh7TpI4zdGYpYazGAtgTimDWsdsz9xW5aFssOOKg";
            this.tbLineToken01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbLineApi01
            // 
            this.tbLineApi01.Location = new System.Drawing.Point(151, 37);
            this.tbLineApi01.Name = "tbLineApi01";
            this.tbLineApi01.Size = new System.Drawing.Size(821, 39);
            this.tbLineApi01.TabIndex = 12;
            this.tbLineApi01.Text = "https://notify-api.line.me/api/notify";
            this.tbLineApi01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(9, 75);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(146, 32);
            this.label19.TabIndex = 9;
            this.label19.Text = "Line Token :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(9, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(116, 32);
            this.label20.TabIndex = 10;
            this.label20.Text = "Line API :";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(25, 285);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(936, 375);
            this.richTextBox1.TabIndex = 21;
            this.richTextBox1.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(230, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 81);
            this.button1.TabIndex = 5;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1390, 807);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.Rsponse.ResumeLayout(false);
            this.Rsponse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAutoSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chTrend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCycleTime)).EndInit();
            this.Settings.ResumeLayout(false);
            this.Settings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAutoSendSms)).EndInit();
            this.Members.ResumeLayout(false);
            this.Members.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.AGauge aGauge1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblUnit;
        private System.Windows.Forms.Label lblValue;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.ComboBox cbScanedDevice;
        private System.Windows.Forms.CheckBox ckbAlarmLineSms;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Rsponse;
        private System.Windows.Forms.TabPage Settings;
        private System.Windows.Forms.Button btnMeasement;
        private System.Windows.Forms.Button btnStopScan;
        private System.Windows.Forms.Label lblDateTimeNow;
        private System.Windows.Forms.Button btnStopMeasure;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ListView lvData;
        private System.Windows.Forms.ColumnHeader Time;
        private System.Windows.Forms.ColumnHeader Value;
        private System.Windows.Forms.NumericUpDown nudCycleTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbCharateristicsCode;
        private System.Windows.Forms.TextBox tbServiceCode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chTrend;
        private System.Windows.Forms.Button btnLineNotify;
        private System.Windows.Forms.TextBox tbNotifyMsg;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ColumnHeader Unit;
        private System.Windows.Forms.RichTextBox rtbResponse;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNormalMaxValue;
        private System.Windows.Forms.TextBox tbNormalMinValue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox ckbOnMqttPub;
        private System.Windows.Forms.CheckBox ckbAlarmTeleSms;
        private System.Windows.Forms.TextBox tbPwdRight;
        private System.Windows.Forms.TextBox tbMqttPubTopic01;
        private System.Windows.Forms.TextBox tbMqttSubTopic01;
        private System.Windows.Forms.TextBox tbId;
        private System.Windows.Forms.TextBox tbMqttServer;
        private System.Windows.Forms.TextBox tbLineToken;
        private System.Windows.Forms.TextBox tbLineApi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbMqttSubTopic02;
        private System.Windows.Forms.TextBox tbMqttPubTopic02;
        private System.Windows.Forms.TextBox tbMqttPubPrefix;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbMqttPubSuffix;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbTeleToken;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbTeleId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox ckbAutoSave;
        private System.Windows.Forms.Button btnSaveSettings;
        private System.Windows.Forms.TextBox tbPwdLeft;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblSite;
        private System.Windows.Forms.TabPage Members;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbLineToken05;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tbLineToken04;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbLineToken03;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbLineToken02;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbLineToken01;
        private System.Windows.Forms.TextBox tbLineApi01;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbTeleToken05;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox tbTeleId05;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox tbTeleToken04;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox tbTeleId04;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox tbTeleToken03;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox tbTeleId03;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbTeleToken02;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbTeleId02;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbTeleToken01;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbTeleId01;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown nudAutoSave;
        private System.Windows.Forms.ComboBox cbBleName;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.CheckBox cbPt100;
        private System.Windows.Forms.TextBox tbPt100OffSet;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox tbPt100Cf;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnAcknowledgeAlarm;
        private System.Windows.Forms.Label lblMqttState;
        private System.Windows.Forms.NumericUpDown nudAutoSendSms;
        private System.Windows.Forms.CheckBox cbAutoSmsCheck;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button1;
    }
}