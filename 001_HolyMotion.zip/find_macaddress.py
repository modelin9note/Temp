import asyncio
from bleak import BleakScanner
import pandas as pd

dicBleDevice  = dict()

async def scan_for_devices():
    print("Scanning for BLE devices...")
    devices = await BleakScanner.discover()

    for device in devices:
        print(f"Device found: {device.name}, MAC Address: {device.address}")
        dicBleDevice[device.name] = device.address

    if not devices:
        print("No BLE devices found.")
        
    # if dicBleDevice :
    #     df = pd.DataFrame(dicBleDevice)
    #     df.to_csv("dfBleDevice.csv")        

asyncio.run(scan_for_devices())



