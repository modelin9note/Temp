﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AutoRoutine
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

        }

        bool bDoMeasure = false;
        DateTime dtOldTime;



        private void frmMain_Load(object sender, EventArgs e)
        {
            //this.FormBorderStyle = FormBorderStyle.FixedSingle;
            //this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            dtOldTime = DateTime.Now;

            string[] lstTime = { "sec", "min", "hour", "day" };

            cbTime.Items.AddRange(lstTime);
            cbTime.SelectedIndex = 0;

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            bDoMeasure = true;

            Thread thDoMeasure = new Thread(WinScp);
            dtOldTime = DateTime.Now;

            thDoMeasure.Start();

            WriteLog("Start Process...");
        }

        private void WinScp()
        {

            string sFileDir = tbWinScpPath.Text;
            var fileInfo = new FileInfo(sFileDir + tbBatchFileName.Text);

            long lFrequency;



            if (fileInfo.Exists)
            {
                Process proc = null;
                try
                {


                    while (bDoMeasure)
                    {
                        lFrequency = long.Parse(nudCycleTime.Value.ToString());
                        string sTime = cbTime.SelectedItem.ToString();

                        int iRandom = int.Parse(nudRandom.Value.ToString());
                        if (iRandom > 0)
                        {
                            Random random = new Random();
                            iRandom = random.Next(iRandom);
                        }

                        switch (sTime)
                        {
                            case "min":
                                lFrequency = (lFrequency + iRandom) * 60;
                                break;
                            case "hour":
                                lFrequency = (lFrequency + iRandom) * 3600;
                                break;
                            case "day":
                                lFrequency = (lFrequency + iRandom) * 3600 * 24;
                                break;

                            default:
                                lFrequency = (lFrequency + iRandom);
                                break;
                        }

                       

                       

                        TimeSpan tsDiff = DateTime.Now - dtOldTime;

                        if (tsDiff.TotalSeconds > lFrequency)
                        {
                            dtOldTime = DateTime.Now;

                            proc = new Process();
                            proc.StartInfo.WorkingDirectory = sFileDir;
                            proc.StartInfo.FileName = tbBatchFileName.Text;
                            //proc.StartInfo.CreateNoWindow = true;
                            proc.StartInfo.CreateNoWindow = false;
                            proc.Start();
                            proc.WaitForExit();

                            WriteLog("Completed Process!");
                        }


                    }


                }
                catch (Exception ex)
                {

                    //WriteLog(ex.StackTrace.ToString());
                    WriteLog(ex.ToString());
                }
            }
            else
            {

            }
        }

        private void WriteLog(string sLog)
        {
            //if (rtbLog.Text.Length > 1000)
            //    rtbLog.Text = DateTime.Now.ToString() + " " + sLog;
            //else
            //    rtbLog.Text = rtbLog.Text + "\r\n" + DateTime.Now.ToString() + " " + sLog;

            rtbLog.Text += "\r\n" + DateTime.Now.ToString() + " : " + sLog+"\r\n";

            rtbLog.SelectionStart = rtbLog.Text.Length;
            rtbLog.ScrollToCaret();
            rtbLog.Refresh();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            bDoMeasure = false;
            WriteLog("Stop Process....");
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
            openFile.FilterIndex = 2;
            openFile.RestoreDirectory = true;

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                tbWinScpPath.Text = Path.GetDirectoryName(openFile.FileName.ToString()) + "\\";
                tbBatchFileName.Text = openFile.SafeFileName.ToString();
                rtbLog.Text = File.ReadAllText(openFile.FileName);
            }
        }

        private void btnSaveBatchFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "batch files (*.bat)|*.bat|All files (*.*)|*.*";
            saveFile.FilterIndex = 1;
            saveFile.RestoreDirectory = true;

            if (saveFile.ShowDialog() == DialogResult.OK)
            {

                File.WriteAllText(saveFile.FileName, tbBatchFileName.Text);

                tbWinScpPath.Text = Path.GetDirectoryName(saveFile.FileName.ToString()) + "\\";
                tbBatchFileName.Text = Path.GetFileName(saveFile.FileName.ToString());
                File.WriteAllText(saveFile.FileName, rtbLog.Text);

                Thread.Sleep(1000);

                rtbLog.Text = File.ReadAllText(saveFile.FileName);
            }
        }

        private void nudRandom_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
