﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BleDmmMonitor
{


    [Serializable]
    public class EnvData
    {
        public string sId { get; set; }
        public string sPwd { get; set; }
        public string sServiceCode { get; set; }
        public string sCharateristics { get; set; }
        public string sLineApi { get; set; }
        public string sLineToken { get; set; }
        public string sTelegramId { get; set; }
        public string sTelegramToken { get; set; }
        public string sMqttServer { get; set; }
        public string sMqttSubTopic1 { get; set; }
        public string sMqttSubTopic2 { get; set; }
        public string sMqttPubTopic1 { get; set; }
        public string sMqttPubTopic2 { get; set; }
        public string sMqttPrefix { get; set; }
        public string sMqttSuffix { get; set; }
        public string sNotifyMsg { get; set; }

        public string sLineApi01 { get; set; }
        public string sLineToken01 { get; set; }
        public string sLineToken02 { get; set; }
        public string sLineToken03 { get; set; }
        public string sLineToken04 { get; set; }
        public string sLineToken05 { get; set; }
        public string sTelegramId01 { get; set; }
        public string sTelegramId02 { get; set; }
        public string sTelegramId03 { get; set; }
        public string sTelegramId04 { get; set; }
        public string sTelegramId05 { get; set; }
        public string sTelegramToken01 { get; set; }
        public string sTelegramToken02 { get; set; }
        public string sTelegramToken03 { get; set; }
        public string sTelegramToken04 { get; set; }
        public string sTelegramToken05 { get; set; }


    }
}
