﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BleDmmMonitor
{
    internal class Decoder
    {
        public static string PreProcess(string value)
        {
            // value = 1b8472b1592ad96a67aa  / value.length = 20
            // error = 1b847258a2ba57e76aa
            if (value.Length < 20 )
            {
                //value = "1b8472b1592ad96a67aa";
                value = "1b8472b18ca2177666aa";
            }
            List<int> hexData = new List<int>();
            for (int i = 0; i < value.Length; i += 2)
            {
                hexData.Add(Convert.ToInt32(value.Substring(i, 2), 16));
            }

            string HexToBinary(int x)
            {
                return Convert.ToString(x, 2).PadLeft(8, '0');
            }

            string LsbToMsb(string x)
            {
                return new string(x.ToCharArray().Reverse().ToArray());
            }

            byte[] xorKey = { 0x41, 0x21, 0x73, 0x55, 0xA2, 0xC1, 0x32, 0x71, 0x66, 0xAA, 0x3B, 0xD0, 0xE2, 0xA8, 0x33, 0x14, 0x20, 0x21, 0xAA, 0xBB };
            List<string> binaryArray = new List<string>();
            StringBuilder fullBinary = new StringBuilder();
            for (int x = 0; x < hexData.Count; x++)
            {
                int toHex = hexData[x] ^ xorKey[x];
                string toBinary = HexToBinary(toHex);
                string flipped = LsbToMsb(toBinary);
                binaryArray.Add(flipped);
                fullBinary.Append(flipped);
            }
            return fullBinary.ToString();
        }


        public static class CheckType
        {
            private static Dictionary<string, string> type_dict = new Dictionary<string, string>
            {
                // 1. Multimeter (1):	Aneng 9002	BSIDE ZT-300AB	ZOYI ZT-300AB	BABATools AD900
                {"11000000", "1"},
                // 2. Small-Multimeter (2):	Aneng V05B	BSIDE ZT-5B	ZOYI ZT-5B	
                {"01000000", "2"},
                // 3. Clamp-Multimeter (3):	Aneng ST207	BSIDE ZT-5BQ	ZOYI ZT-5BQ
                {"10000000", "3"},
                // 4. Clamp-Multimeter (4): image	Aneng AN999S		ZOYI ZT-5566S
                {"00100000", "4"}
            };

            public static string Decode(string origin_value)
            {
                return PreProcess(origin_value);
            }

            public static string Type(string origin_value)
            {
                string type_code = "";

                for (int i = 16; i < 24; i++)
                {
                    type_code += Decode(origin_value)[i];
                }

                if (type_dict.TryGetValue(type_code, out string type))
                {
                    return type;
                }
                else
                {
                    return null;
                }
            }

        }



        public static class DecodingType3
        {
            private static readonly Dictionary<string, string> digit_dict = new Dictionary<string, string>
            {
                {"1110111", "0"},
                {"0010010", "1"},
                {"1011101", "2"},
                {"1011011", "3"},
                {"0111010", "4"},
                {"1101011", "5"},
                {"1101111", "6"},
                {"1010010", "7"},
                {"1111111", "8"},
                {"1111011", "9"},
                {"1111110", "A"},
                {"0000111", "u"},
                {"0101101", "t"},
                {"0001111", "o"},
                {"0100101", "L"},
                {"1101101", "E"},
                {"1101100", "F"},
                {"0001000", "-"}
            };


            public static string decode(string origin_value)
            {
                return PreProcess(origin_value);
            }


            public static string digit(string segment, string digi)
            {
                string signal = segment.Substring(3, 1) + segment.Substring(2, 1) + segment.Substring(7, 1) + segment.Substring(6, 1) + segment.Substring(1, 1) + segment.Substring(5, 1) + segment.Substring(4, 1);
                try
                {
                    if (digi != null)
                    {
                        digi += digit_dict[signal];
                    }
                }
                catch
                {
                    digi += "";
                }
                return digi;
            }

            public static string printdigit(string prepared)
            {
                string digi = "";
                Console.WriteLine(prepared);
                Console.WriteLine(prepared.Substring(16, 1) + prepared.Substring(17, 1) + prepared.Substring(18, 1) + prepared.Substring(19, 1) + prepared.Substring(20, 1) + prepared.Substring(21, 1) + prepared.Substring(22, 1) + prepared.Substring(23, 1));
                if (prepared[28] == '1')
                {
                    if (digi != null)
                    {
                        digi += "-";
                    }
                }
                digi = digit(prepared.Substring(28, 8), digi);
                if (prepared[36] == '1')
                {
                    if (digi != null)
                    {
                        digi += ".";
                    }
                }
                digi = digit(prepared.Substring(36, 8), digi);
                if (prepared[44] == '1')
                {
                    if (digi != null)
                    {
                        digi += ".";
                    }
                }
                digi = digit(prepared.Substring(44, 8), digi);
                if (prepared[52] == '1')
                {
                    if (digi != null)
                    {
                        digi += ".";
                    }
                }
                digi = digit(prepared.Substring(52, 8), digi);
                if (digi == null)
                {
                    digi = "0";
                }
                return digi;
            }

            public static List<string> printchar(string prepared)
            {
                // prepared = "01011010101001011000000000100000000000000000010110110001010100000000000000010000"
                List<string> char_function = new List<string>();
                List<string> char_unit = new List<string>();
                string[] bits_1 = { "HOLD", "Flash", "BUZ" };
                for (int i = 25; i < 28; i++)
                {
                    if (prepared[i] == '1')
                    {
                        char_function.Add(bits_1[i - 25]);
                    }
                }
                string[] bits_2 = { "n", "V", "DC", "AC", "F", "->", "A", "μ", "Ω", "k", "m", "M", "", "Hz", "°F", "°C", "", "", "", "" };
                HashSet<int> function = new HashSet<int> { 65, 69 };
                for (int i = 59 + bits_2.Length - 1; i > 59; i--)
                {
                    if (function.Contains(i))
                    {
                        if (prepared[i] == '1')
                        {
                            char_function.Add(bits_2[i - 60]);
                        }
                    }
                    else
                    {
                        if (prepared[i] == '1')
                        {
                            char_unit.Add(bits_2[i - 60]);
                        }
                    }
                }
                return new List<string> { string.Join(", ", char_function), string.Join(", ", char_unit) };
            }
        }
    }
}
