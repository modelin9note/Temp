﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BleDmmMonitor
{

    public static class JsonSerialize
    {
        public static void SaveEnvDataJson(EnvData envData, string sSite)
        {
            //string sFileDir = @"c:\TheSeaLab\Env\";
            string sFileDir = @"c:\TheSeaLab\" + sSite + "\\Env\\";
            var fileInfo = new FileInfo(sFileDir + "Env.json");
            if (!fileInfo.Exists)
            {
                Directory.CreateDirectory(fileInfo.DirectoryName);
            }


            string sJson = JsonConvert.SerializeObject(envData);

            //var builder = new StringBuilder();
            //builder.Append(sJson);
            //File.WriteAllText(fileInfo.FullName, builder.ToString());


            byte[] baByte = Encoding.UTF8.GetBytes(sJson);
            string encodedJson = System.Convert.ToBase64String(baByte);
            File.WriteAllText(fileInfo.FullName, encodedJson);


            //EnvData deSerialJson = new EnvData();
            //deSerialJson = JsonConvert.DeserializeObject<EnvData>(sJson);
            //MessageBox.Show(deSerialJson.sId);
        }

        public static EnvData LoadFromJson(string sSite)
        {
            //string sFileDir = @"c:\TheSeaLab\Env\";
            string sFileDir = @"c:\TheSeaLab\" + sSite + "\\Env\\";
            var fileInfo = new FileInfo(sFileDir + "Env.json");
            if (!fileInfo.Exists)
            {
                Directory.CreateDirectory(fileInfo.DirectoryName);
            }

            string sJson;
            try
            {
                sJson = File.ReadAllText(fileInfo.FullName);
                byte[] baByte = System.Convert.FromBase64String(sJson);
                string sDecodedJson = System.Text.Encoding.UTF8.GetString(baByte);
                EnvData eData = JsonConvert.DeserializeObject<EnvData>(sDecodedJson);

                return eData;

            }
            catch (Exception ex)
            {

                throw;
            }

            //string sJson = JsonConvert.SerializeObject(envData);
        }
    }
}
