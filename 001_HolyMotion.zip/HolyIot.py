import asyncio
from bleak import BleakScanner

# Constants for your specific device
# Holy-IOT, MAC Address: DF:42:C8:51:45:6F
# TARGET_DEVICE_MAC = "A838554B-CEEE-D90A-A3AB-8499CBA95BAE"
TARGET_DEVICE_MAC = "DF:42:C8:51:45:6F"

def parse_beacon_data(hex_string):
    # Convert hex string to bytes
    data_bytes = bytes.fromhex(hex_string)

    # Parse UUID, Major, Minor, and Power
    uuid = hex_string[4:36]
    major = int(hex_string[36:40], 16)
    minor = int(hex_string[40:44], 16)
    power = int(hex_string[44:46], 16) - 256 if int(hex_string[44:46], 16) > 127 else int(hex_string[44:46], 16)

    return {
        'UUID': uuid,
        'Major': major,
        'Minor': minor,
        'Power': power
    }

def parse_service_data(data_bytes):
    temp_parts = [int.from_bytes(data_bytes[i:i+1], byteorder='big', signed=False) for i in range(0, 2)]
    humidity_parts = [int.from_bytes(data_bytes[i:i+1], byteorder='big', signed=False) for i in range(2, 4)]

    # Concatenate the parts for temperature and humidity
    temp_str = ''.join(str(part) for part in temp_parts)
    humidity_str = ''.join(str(part) for part in humidity_parts)

    # Convert the concatenated string to integer
    temperature = int(temp_str)
    humidity = int(humidity_str)

    # Convert each accelerometer byte to an integer and concatenate
    accel_x_parts = [int.from_bytes(data_bytes[i:i+1], byteorder='big', signed=True) for i in range(5, 8)]
    accel_y_parts = [int.from_bytes(data_bytes[i:i+1], byteorder='big', signed=True) for i in range(9, 12)]
    accel_z_parts = [int.from_bytes(data_bytes[i:i+1], byteorder='big', signed=True) for i in range(13, 16)]

    # Concatenate the parts for each axis
    accel_x_str = ''.join(str(part) for part in accel_x_parts)
    accel_y_str = ''.join(str(part) for part in accel_y_parts)
    accel_z_str = ''.join(str(part) for part in accel_z_parts)

    # Convert the concatenated string to integer
    accel_x = int(accel_x_str)
    accel_y = int(accel_y_str)
    accel_z = int(accel_z_str)

    sign_bytex = data_bytes[4] 
    sign_bytey = data_bytes[8] 
    sign_bytez = data_bytes[12] 

    if sign_bytex == 0:
        accel_x = -accel_x
    if sign_bytey == 0:
        accel_y = -accel_y
    if sign_bytez == 0:
        accel_z = -accel_z

    return {
        'Temperature': temperature/100,
        'Humidity': humidity/100,
        'Accelerometer X': accel_x / 100.0,  
        'Accelerometer Y': accel_y / 100.0,  
        'Accelerometer Z': accel_z / 100.0,  
    }

def detection_callback(device, advertisement_data):
    if device.address.lower() == TARGET_DEVICE_MAC.lower():
        print(f"Found target device: {device.address}")
      #  print("Advertisement Data:", advertisement_data)
        # print("Advertisement Data:", advertisement_data)

        # Manufacturer Data
        manufacturer_data = advertisement_data.manufacturer_data.get(76)
        if manufacturer_data:
           # print("Raw Manufacturer Data:", manufacturer_data.hex())
            # print("Raw Manufacturer Data:", manufacturer_data.hex())
            decoded_data = parse_beacon_data(manufacturer_data.hex())
            if decoded_data:
                print("Decoded Manufacturer Data:", decoded_data)

        specific_service_data = advertisement_data.service_data.get('00000318-0000-1000-8000-00805f9b34fb')
        if specific_service_data:
            #print("Specific Service Data (Bytes):", specific_service_data)
            # print("Specific Service Data (Bytes):", specific_service_data)
            decoded_data = parse_service_data(specific_service_data)
            print("Decoded Service Data:", decoded_data)


async def main():
    scanner = BleakScanner()
    scanner.register_detection_callback(detection_callback)

    await scanner.start()
    # await asyncio.sleep(600)  # Scan for 20 seconds
    await asyncio.sleep(15)  # Scan for 20 seconds
    await scanner.stop()

asyncio.run(main())