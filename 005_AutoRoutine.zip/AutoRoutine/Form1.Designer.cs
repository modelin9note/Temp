﻿namespace AutoRoutine
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbWinScpPath = new System.Windows.Forms.TextBox();
            this.tbBatchFileName = new System.Windows.Forms.TextBox();
            this.btnSelectFile = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rtbLog = new System.Windows.Forms.RichTextBox();
            this.nudCycleTime = new System.Windows.Forms.NumericUpDown();
            this.cbTime = new System.Windows.Forms.ComboBox();
            this.btnSaveBatchFile = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.nudRandom = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCycleTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRandom)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(16, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(502, 72);
            this.button1.TabIndex = 0;
            this.button1.Text = "Auto Routine";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(535, 14);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(258, 72);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(801, 14);
            this.btnStop.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(258, 72);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Repeat Time(sec) : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Batch File Name : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Win SCP Path : ";
            // 
            // tbWinScpPath
            // 
            this.tbWinScpPath.Location = new System.Drawing.Point(156, 137);
            this.tbWinScpPath.Name = "tbWinScpPath";
            this.tbWinScpPath.Size = new System.Drawing.Size(903, 27);
            this.tbWinScpPath.TabIndex = 7;
            this.tbWinScpPath.Text = "C:\\WorkPlace\\AutoRoutine\\BatFiles\\";
            // 
            // tbBatchFileName
            // 
            this.tbBatchFileName.Location = new System.Drawing.Point(156, 171);
            this.tbBatchFileName.Name = "tbBatchFileName";
            this.tbBatchFileName.Size = new System.Drawing.Size(903, 27);
            this.tbBatchFileName.TabIndex = 8;
            this.tbBatchFileName.Text = "Test.bat";
            // 
            // btnSelectFile
            // 
            this.btnSelectFile.Location = new System.Drawing.Point(535, 96);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Size = new System.Drawing.Size(258, 37);
            this.btnSelectFile.TabIndex = 9;
            this.btnSelectFile.Text = "Select File";
            this.btnSelectFile.UseVisualStyleBackColor = true;
            this.btnSelectFile.Click += new System.EventHandler(this.btnSelectFile_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtbLog);
            this.groupBox1.Location = new System.Drawing.Point(13, 224);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1046, 396);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LOG";
            // 
            // rtbLog
            // 
            this.rtbLog.Location = new System.Drawing.Point(3, 23);
            this.rtbLog.Name = "rtbLog";
            this.rtbLog.Size = new System.Drawing.Size(1040, 370);
            this.rtbLog.TabIndex = 0;
            this.rtbLog.Text = "";
            // 
            // nudCycleTime
            // 
            this.nudCycleTime.Location = new System.Drawing.Point(156, 103);
            this.nudCycleTime.Maximum = new decimal(new int[] {
            3600000,
            0,
            0,
            0});
            this.nudCycleTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCycleTime.Name = "nudCycleTime";
            this.nudCycleTime.Size = new System.Drawing.Size(114, 27);
            this.nudCycleTime.TabIndex = 11;
            this.nudCycleTime.Value = new decimal(new int[] {
            399,
            0,
            0,
            0});
            // 
            // cbTime
            // 
            this.cbTime.FormattingEnabled = true;
            this.cbTime.Location = new System.Drawing.Point(276, 103);
            this.cbTime.Name = "cbTime";
            this.cbTime.Size = new System.Drawing.Size(59, 28);
            this.cbTime.TabIndex = 12;
            // 
            // btnSaveBatchFile
            // 
            this.btnSaveBatchFile.Location = new System.Drawing.Point(801, 94);
            this.btnSaveBatchFile.Name = "btnSaveBatchFile";
            this.btnSaveBatchFile.Size = new System.Drawing.Size(258, 37);
            this.btnSaveBatchFile.TabIndex = 9;
            this.btnSaveBatchFile.Text = "Save Batch File";
            this.btnSaveBatchFile.UseVisualStyleBackColor = true;
            this.btnSaveBatchFile.Click += new System.EventHandler(this.btnSaveBatchFile_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(350, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Random";
            // 
            // nudRandom
            // 
            this.nudRandom.Location = new System.Drawing.Point(422, 105);
            this.nudRandom.Maximum = new decimal(new int[] {
            3600000,
            0,
            0,
            0});
            this.nudRandom.Name = "nudRandom";
            this.nudRandom.Size = new System.Drawing.Size(96, 27);
            this.nudRandom.TabIndex = 14;
            this.nudRandom.Value = new decimal(new int[] {
            199,
            0,
            0,
            0});
            this.nudRandom.ValueChanged += new System.EventHandler(this.nudRandom_ValueChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 635);
            this.Controls.Add(this.nudRandom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbTime);
            this.Controls.Add(this.nudCycleTime);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSaveBatchFile);
            this.Controls.Add(this.btnSelectFile);
            this.Controls.Add(this.tbBatchFileName);
            this.Controls.Add(this.tbWinScpPath);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Malgun Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudCycleTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRandom)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbWinScpPath;
        private System.Windows.Forms.TextBox tbBatchFileName;
        private System.Windows.Forms.Button btnSelectFile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rtbLog;
        private System.Windows.Forms.NumericUpDown nudCycleTime;
        private System.Windows.Forms.ComboBox cbTime;
        private System.Windows.Forms.Button btnSaveBatchFile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudRandom;
    }
}

